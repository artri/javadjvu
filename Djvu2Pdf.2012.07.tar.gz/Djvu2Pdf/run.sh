#!/bin/sh
if [ -f lib/swt.jar ]; then
java -Xmx980m -jar djvu2pdf.jar
else
echo No swt.jar found. Please download one for your platform from http://download.eclipse.org/eclipse/downloads/drops/R-3.6.1-201009090800/index.php#SWT 
fi

