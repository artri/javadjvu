package org.zefer.djvupdf;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.image.ImageProducer;
import java.awt.image.PixelGrabber;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;

import org.eclipse.swt.widgets.Display;

import com.lizardtech.djvu.DjVuOptions;
import com.lizardtech.djvu.DjVuPage;
import com.lizardtech.djvu.Document;
import com.lizardtech.djvubean.DjVuFilter;

public class DjvuBook extends Book {

	private Document document;

	static {
		DjVuOptions.out = new PrintStream(new NullPrintStream());
		DjVuOptions.err = DjVuOptions.out;
	}
	
	public DjvuBook( String activeDocument, boolean doublePage, int targetWidth, int targetHeight ) throws IOException {
			document = new Document(new URL("file:" + activeDocument));
			document.setAsync(false);
			this.doublePage = doublePage;
			this.targetHeight = targetHeight;
			this.targetWidth = targetWidth;
	}
	
	public DjvuBook() {
	}

	public void setDoublePage(boolean doublePage) {
		if ( this.doublePage != doublePage ) {
			cache.clear();
		}
		super.setDoublePage(doublePage);
	}

	public void setTargetDimensions(int width, int height) {
		if(this.targetWidth != width || this.targetHeight != height ) {
			cache.clear();
		}
		super.setTargetDimensions(width, height);
	}
	
	public static class NullPrintStream extends OutputStream {
		public void write(byte[] buf, int off, int len) {}
		public void write(int b) {}
		public void write(byte [] b) {}
	}

	public int getTotalPages() {
		
		if ( document == null ) {
			return 0;
		}
		
		return document.size() * (doublePage ? 2 : 1);
	}

	private HashMap cache = new HashMap();
	private static final int CACHE_SIZE = 15;
	
	public BookPage getPage( int pageNumber, final boolean split, final double imageScale, final Display display, boolean background ) throws IOException {
		
		if ( document == null ) {
			return null;
		}

		if ( pageNumber < 0 || pageNumber > getTotalPages() - 1 ) {
			return null;
		}

		boolean loadNext = false;
		boolean loadPrev = false;
		
		int pn = doublePage ? pageNumber / 2 : pageNumber;
		
		BookPage result = (BookPage)cache.get(""+pageNumber);
		if ( result != null ) {
			if ( result.split == split ) {
				
//				System.out.println("got from cache!");
				
			} else {
				cache.remove(""+pageNumber);
				result = null;
			}
		}

		if ( !background ) {
			BookPage next = (BookPage)cache.get(""+(pageNumber+1));
			if ( next != null ) {
				if ( next.split != split ) {
					cache.remove(""+(pageNumber+1));
					loadNext = true;
				}
			} else {
				loadNext = true;
			}
			BookPage prev = (BookPage)cache.get(""+(pageNumber-1));
			if ( prev != null ) {
				if ( prev.split != split ) {
					cache.remove(""+(pageNumber-1));
					loadPrev = true;
				}
			} else {
				loadPrev = true;
			}
		}
		
		if ( result == null ) {

			result = new BookPage();
			result.split = split;
			
			double desiredHeight = (split ? targetWidth*2 : targetHeight) * imageScale * 1.4;
			int desiredWidth;

			java.awt.Image ii = null;
			int wx;
			int hx;
			
			if ( doublePage ) {
				
				boolean left = pageNumber % 2 == 0;
				pageNumber /= 2;
				
				DjVuPage page = document.getPage(pageNumber, 1, false);

				wx = page.getInfo().width;
				hx = page.getInfo().height;
				
				desiredWidth = (int)((wx * desiredHeight)/hx);
				
				if ( left ) {
					ImageProducer ip = new DjVuFilter(new Rectangle(0, 0, desiredWidth/2, (int)desiredHeight), new Dimension(desiredWidth, (int)desiredHeight), page, false).getImageProducer();
					ii = Toolkit.getDefaultToolkit().createImage(ip);
				} else {
					ImageProducer ip = new DjVuFilter(new Rectangle(desiredWidth/2, 0, desiredWidth/2, (int)desiredHeight), new Dimension(desiredWidth, (int)desiredHeight), page, false).getImageProducer();
					ii = Toolkit.getDefaultToolkit().createImage(ip);
				}

				wx = desiredWidth / 2;
				hx = (int)desiredHeight;

			} else {
				DjVuPage page = document.getPage(pageNumber, 1, false);

				wx = page.getInfo().width;
				hx = page.getInfo().height;
				
				desiredWidth = (int)((wx * desiredHeight)/hx);
				
				ImageProducer ip = new DjVuFilter(new Rectangle(0, 0, desiredWidth, (int)desiredHeight), new Dimension(desiredWidth, (int)desiredHeight), page, false).getImageProducer();
				ii = Toolkit.getDefaultToolkit().createImage(ip);

				wx = desiredWidth;
				hx = (int)desiredHeight;
			}

			result.width = wx;
			result.height = hx;
			result.data = new int[wx * hx];

			PixelGrabber pg = new PixelGrabber(ii, 0, 0, wx, hx, result.data, 0, wx);
			try {
				pg.grabPixels();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			cache.put(""+pageNumber, result);
		}

		if ( !background ) {
			if ( cache.size() > CACHE_SIZE ) {
//				System.out.println( "clean cache..." );
				do {
					int max = pageNumber;
					Iterator ii = cache.keySet().iterator();
					while ( ii.hasNext() ) {
						String k = (String)ii.next();
						int kk = Integer.parseInt( k );
						if ( Math.abs(kk-pageNumber) > Math.abs(max-pageNumber)  ) {
							max = kk;
						}
					}
					cache.remove(""+max);
//					System.out.println( "page " + max + " removed..." );
				} while( cache.size() > CACHE_SIZE );
			}

			if ( loadNext && loadPrev ) {
				final int pnx = pageNumber;
	    		Thread t = new Thread() {
	    		    public void run() {
	    	    		try {
	    	    			sleep(800);
	    	    			String xname = "djreader"+(pnx+1); 
	    	    			if ( doesNotLoad(xname) ) {
	    	    				setName(xname);
	    	    				getPage(pnx + 1, split, imageScale, display, true);
//	    	    				System.out.println( (pnx+1) + " cached...");
	    	    			}
	    	    			xname="djreader"+(pnx-1);
	    	    			if ( doesNotLoad(xname) ) {
	    	    				setName(xname);
	    	    				getPage(pnx - 1, split, imageScale, display, true);
//	    	    				System.out.println( (pnx-1) + " cached...");
	    	    			}
	    	    		} catch (Exception e1) {
	    	    			e1.printStackTrace();
	    	    		}
	    		    }
	    		};
	    		t.setPriority(Thread.MIN_PRIORITY);
	    		t.start();
			} else if ( loadPrev ) {
				final int pnx = pageNumber - 1;
	    		Thread t = new Thread() {
	    		    public void run() {
	    	    		try {
	    	    			sleep(800);
	    	    			String xname = "djreader"+pnx; 
	    	    			if ( doesNotLoad(xname) ) {
	    	    				setName(xname);
	    	    				getPage(pnx, split, imageScale, display, true);
//	    	    				System.out.println( pnx + " cached...");
	    	    			}
	    	    		} catch (Exception e1) {
	    	    			e1.printStackTrace();
	    	    		}
	    		    }
	    		};
	    		t.setPriority(Thread.MIN_PRIORITY);
	    		t.start();
			} else if( loadNext ) {
				final int pnx = pageNumber + 1;
	    		Thread t = new Thread() {
	    		    public void run() {
	    	    		try {
	    	    			sleep(800);
	    	    			String xname = "djreader"+(pnx+1);
	    	    			if ( doesNotLoad(xname) ) {
	    	    				setName(xname);
	    	    				getPage(pnx+1, split, imageScale, display, true);
//	    	    				System.out.println( (pnx+1) + " cached...");
	    	    			}
	    	    			xname = "djreader"+pnx; 
	    	    			if ( doesNotLoad(xname) ) {
	    	    				setName(xname);
	    	    				getPage(pnx, split, imageScale, display, true);
//	    	    				System.out.println( pnx + " cached...");
	    	    			}
	    	    		} catch (Exception e1) {
	    	    			e1.printStackTrace();
	    	    		}
	    		    }
	    		};
	    		t.setPriority(Thread.MIN_PRIORITY);
	    		t.start();
			}
		}
		
		return result;
	}
	
	private boolean doesNotLoad( String xname ) {
		ThreadGroup rootGroup = Thread.currentThread().getThreadGroup( );
		ThreadGroup parentGroup;
		while ( ( parentGroup = rootGroup.getParent() ) != null ) {
		    rootGroup = parentGroup;
		}
		return !checkGroup(xname, rootGroup, "");
	}

	private boolean checkThread(String xname, Thread t, String indent) {
		if (t == null) {
			return false;
		}
		if ( t.getName().equals(xname) ) {
//			System.out.println( xname + " already loads");
			return true;
		}
		return false;
	}
	  
	private boolean checkGroup(String xname, ThreadGroup g, String indent) {
		if (g == null) {
			return false;
		}
		int numThreads = g.activeCount();
		int numGroups = g.activeGroupCount();
		Thread[] threads = new Thread[numThreads];
		ThreadGroup[] groups = new ThreadGroup[numGroups];

		g.enumerate(threads, false);
		g.enumerate(groups, false);

		for (int i = 0; i < numThreads; i++) {
			boolean b = checkThread(xname, threads[i], indent + "    ");
			if ( b ) {
				return b;
			}
		}
		for (int i = 0; i < numGroups; i++) {
			boolean b = checkGroup(xname, groups[i], indent + "    ");
			if ( b ) {
				return b;
			}
		}
		return false;
	}
}
