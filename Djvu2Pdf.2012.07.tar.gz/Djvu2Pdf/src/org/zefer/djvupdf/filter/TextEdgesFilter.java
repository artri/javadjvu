package org.zefer.djvupdf.filter;

public class TextEdgesFilter {
	public static void filterText( int[] imageData, int width, int height, int f1, int f2, float f3, float f4 ) {

//		long start = System.currentTimeMillis();
		
		int[] mask = filterEdgePixels(width, height, imageData);
		
		for ( int x = 0; x < width; x++ ) {
			for ( int y = 0; y < height; y++ ) {
				int pixel = mask[x + y * width];
				if ( isMasked( pixel, f1 ) ) {

					if ( x > 0 && x < width - 1 ) {
						int leftPixel = mask[x - 1 + y * width];
						int rightPixel = mask[x + 1 + y * width];
						if ( !isMasked( leftPixel, f1 ) && !isMasked( rightPixel, f1 ) ) {
							continue;
						}
					}
					if ( y > 0 && y < height - 1 ) {
						int upPixel = mask[x + (y - 1) * width];
						int doPixel = mask[x + (y + 1) * width];
						if ( !isMasked( upPixel, f1 ) && !isMasked( doPixel, f1 ) ) {
							continue;
						}
					}
					pixel = imageData[x + y * width];
					if ( !isMasked( pixel, f2 ) ) {
						imageData[x + y * width] = 0xffffff;
					}
				}
			}
		}

//		filterLevels(width, height, imageData, f3, f4);

//	    System.out.println( "edges duration: " + (System.currentTimeMillis() - start) + " " + f1 + " " + f2 + " " + f3 );
	}
		
	protected static int[] filterEdgePixels( int width, int height, int[] inPixels ) {

		float[] vEdgeMatrix = {
			-1,  0,  1,
			-2,  0,  2,
			-1,  0,  1,
		};

		float[] hEdgeMatrix = {
			-1, -2, -1,
			0,  0,  0,
			1,  2,  1,
		};
		
		int index = 0;
		int[] outPixels = new int[width * height];

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				int r = 0, g = 0, b = 0;
				int rh = 0, gh = 0, bh = 0;
				int rv = 0, gv = 0, bv = 0;
				int a = inPixels[y*width+x] & 0xff000000;

				for (int row = -1; row <= 1; row++) {
					int iy = y+row;
					int ioffset;
					if (0 <= iy && iy < height)
						ioffset = iy*width;
					else
						ioffset = y*width;
					int moffset = 3*(row+1)+1;
					for (int col = -1; col <= 1; col++) {
						int ix = x+col;
						if (!(0 <= ix && ix < width))
							ix = x;
						int rgb = inPixels[ioffset+ix];
						float h = hEdgeMatrix[moffset+col];
						float v = vEdgeMatrix[moffset+col];

						r = (rgb & 0xff0000) >> 16;
						g = (rgb & 0x00ff00) >> 8;
						b = rgb & 0x0000ff;
						rh += (int)(h * r);
						gh += (int)(h * g);
						bh += (int)(h * b);
						rv += (int)(v * r);
						gv += (int)(v * g);
						bv += (int)(v * b);
					}
				}
				r = (int)(Math.sqrt(rh*rh + rv*rv) / 1.8);
				g = (int)(Math.sqrt(gh*gh + gv*gv) / 1.8);
				b = (int)(Math.sqrt(bh*bh + bv*bv) / 1.8);
				r = clamp(r);
				g = clamp(g);
				b = clamp(b);
				outPixels[index++] = a | (r << 16) | (g << 8) | b;
			}

		}
		return outPixels;
	}

	public static int[] filterLevels( int width, int height, int[] inPixels, float white, float black ) {
		
		long start = System.currentTimeMillis();
		
		Histogram histogram = new Histogram(inPixels, width, height, 0, width);

		System.out.println( "min: " + histogram.getMinFrequency() );
		System.out.println( "max: " + histogram.getMaxFrequency() );

		System.out.println( "hist: " + (System.currentTimeMillis()-start) );

		int i, j;
		int[][] lut;

		float lowLevel = black;
	    float highLevel = white;
	    float lowOutputLevel = 0;
	    float highOutputLevel = 1;

		if (histogram.getNumSamples() > 0) {
//			float scale = 255.0f / histogram.getNumSamples();
			lut = new int[3][256];

            float low = lowLevel * 255;
            float high = highLevel * 255;
            if ( low == high ) {
            	high++;
            }
			for (i = 0; i < 3; i++) {
				for (j = 0; j < 256; j++) {
					lut[i][j] = clamp( (int)(255 * (lowOutputLevel + (highOutputLevel-lowOutputLevel) * (j-low)/(high-low))) );
				}
			}
		} else {
			lut = null;
		}

		i = 0;
		for (int y = 0; y < height; y++)
			for (int x = 0; x < width; x++) {
				inPixels[i] = filterRGB(x, y, inPixels[i], lut);
				i++;
			}
		lut = null;
		
		return inPixels;
	}

	public static int filterRGB(int x, int y, int rgb, int[][] lut) {
		if (lut != null) {
			int a = rgb & 0xff000000;
			int r = lut[Histogram.RED][(rgb >> 16) & 0xff];
			int g = lut[Histogram.GREEN][(rgb >> 8) & 0xff];
			int b = lut[Histogram.BLUE][rgb & 0xff];

			return a | (r << 16) | (g << 8) | b;
		}
		return rgb;
	}
	
	private static boolean isMasked( int pixel, int f ) {
//		int alpha = (pixel >> 24) & 0xff;
		int red   = (pixel >> 16) & 0xff;
		int green = (pixel >>  8) & 0xff;
		int blue  = (pixel      ) & 0xff;			
		
		if ( red < f && green < f && blue < f ) {
			return true;
		}
		return false;
	}

	public static int clamp(int c) {
		if (c < 0)
			return 0;
		if (c > 255)
			return 255;
		return c;
	}
}
