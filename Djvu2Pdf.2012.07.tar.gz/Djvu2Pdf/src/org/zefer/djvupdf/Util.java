package org.zefer.djvupdf; 

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Transparency;
import java.awt.color.ColorSpace;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ComponentColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.DirectColorModel;
import java.awt.image.IndexColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.metadata.IIOMetadataNode;
import javax.imageio.stream.ImageInputStream;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;
import org.w3c.dom.NodeList;
import org.zefer.djvupdf.filter.TextEdgesFilter;

public class Util {

	static {
		ImageIO.scanForPlugins();
	}
	
	public static int getSplitPosition(int[] pixels, int w, int h, int overlap) {

		int splitcol = -1;
		int minRank = Integer.MAX_VALUE;

		for (int y = h/2; y < h/2 + overlap; y++) {
			int rank = 0;
			for (int x = 0; x < w; x++) {
				int pixel = pixels[y * w + x];

				int red   = (pixel >> 16) & 0xff;
				int green = (pixel >>  8) & 0xff;
				int blue  = (pixel      ) & 0xff;			

				if ( red + green + blue == 0 ) {
					rank++;
				}
			}
			if(minRank > rank) {
				minRank = rank;
				splitcol = y;
			}
		}

		for (int y = h/2 - 1; y > h/2 - overlap; y--) {
			int rank = 0;
			for (int x = 0; x < w; x++) {
				int pixel = pixels[y * w + x];

				int red   = (pixel >> 16) & 0xff;
				int green = (pixel >>  8) & 0xff;
				int blue  = (pixel      ) & 0xff;			

				if ( red + green + blue == 0 ) {
					rank++;
				}
			}
			if(minRank >= rank) {
				minRank = rank;
				splitcol = y;
			}
		}

		if ( minRank > w/15 ) {
			splitcol = h/2;
			minRank = -1;
		}
		
		return splitcol;
	}

	public static BufferedImage[] rotateAndSplit(int[] pixels, int w, int h, int overlap) {

		BufferedImage[] result = new BufferedImage[2];

		int[] rotate = new int[w * h];
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				rotate[((w - x - 1) * h) + y] = pixels[(y * w) + x];
			}
		}
		int s = w;
		w = h;
		h = s;

		int splitcol = -1;
		int minRank = Integer.MAX_VALUE;

//		System.out.println( "width: " + w + ", height: " + h );
		
		for (int x = w/2; x < w/2 + overlap*2; x++) {
			int rank = 0;
			for (int y = 0; y < h; y++) {
				int pixel = rotate[y * w + x];

				int red   = (pixel >> 16) & 0xff;
				int green = (pixel >>  8) & 0xff;
				int blue  = (pixel      ) & 0xff;			

				if ( red + green + blue == 0 ) {
					rank++;
				}
			}
			if(minRank > rank) {
				minRank = rank;
				splitcol = x;
			}
		}

		for (int x = w/2 - 1; x > w/2 - overlap*2; x--) {
			int rank = 0;
			for (int y = 0; y < h; y++) {
				int pixel = rotate[y * w + x];

				int red   = (pixel >> 16) & 0xff;
				int green = (pixel >>  8) & 0xff;
				int blue  = (pixel      ) & 0xff;			

				if ( red + green + blue == 0 ) {
					rank++;
				}
			}
			if(minRank >= rank) {
				minRank = rank;
				splitcol = x;
			}
		}

		if ( minRank > h/15 ) {
			splitcol = w/2;
			minRank = -1;
		}
		
//		System.out.println( "MIN: " + minRank + ", splitcol: " + splitcol );

		int ctr = 0;
		int newW = splitcol + (minRank < 0 ? overlap : 1);
		int[] left = new int[h * newW];
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < newW; x++) {
				left[ctr++] = rotate[y * w + x];
			}
		}
		result[0] = new BufferedImage(newW,h,BufferedImage.TYPE_INT_RGB);
		result[0].setRGB(0,0,newW,h,left,0,newW);

		ctr = 0;
		newW = w - splitcol;
		left = new int[h * newW];
		for (int y = 0; y < h; y++) {
			for (int x = splitcol; x < w; x++) {
				left[ctr++] = rotate[y * w + x];
			}
		}
		result[1] = new BufferedImage(newW,h,BufferedImage.TYPE_INT_RGB);
		result[1].setRGB(0,0,newW,h,left,0,newW);
		
		return result;
	}


	public static int[] rotate(int[] pixels, int width, int split, boolean first) {
		
		int height = pixels.length / width;
		int ctr = 0;
		int[] rotated = new int[(first ? split : height - split) * width];
		for (int x = width - 1; x >= 0; x--) {
			if ( first ) {
				for (int y = 0; y < split; y++) {
					rotated[ctr++] = 
						pixels[y * width + x];
				}
			} else {
				for (int y = split; y < height; y++) {
					rotated[ctr++] = 
						pixels[y * width + x];
				}
			}
		}
		return rotated;
	}
	
	public static void clean(int[] pixels, int hiedge, int loedge) {
		long max = 0;
		long min = Integer.MAX_VALUE;
		for ( int i = 0; i < pixels.length; i++ ) {
			
			int pixel = pixels[i];
			
			int alpha = (pixel >> 24) & 0xff;
			int red   = (pixel >> 16) & 0xff;
			int green = (pixel >>  8) & 0xff;
			int blue  = (pixel      ) & 0xff;			
			
			if ( red > hiedge && green > hiedge && blue > hiedge ) {
				pixels[i] = 0xffffffff;
			}
			
			if ( red < loedge && green < loedge && blue < loedge ) {
				pixels[i] = 0x0;
			}
			
			max = Math.max(max, alpha);
			min = Math.min(min, alpha);
		}
	}

	public static int[] copyAndProcess(int[] pixels, int width, int height, int hiedge, int loedge, boolean edges) {

//		System.out.println( "hi: " + hiedge + ", lo: " + loedge );

		long start = System.currentTimeMillis();

//		if ( edges ) {
//			int[] result = Arrays.copyOf(pixels, pixels.length);
//			TextEdgesFilter.filterLevels(width, height, result, (100 + hiedge)/256f, loedge/256f);		
////		    System.out.println( "levels duration: " + (System.currentTimeMillis() - start) );
//			return result;
//		} else {
//			long max = 0;
//			long min = Integer.MAX_VALUE;
			int[] result = new int[pixels.length];
			for ( int i = 0; i < pixels.length; i++ ) {
				
				int pixel = pixels[i];
				
//				int alpha = (pixel >> 24) & 0xff;
				int red   = (pixel >> 16) & 0xff;
				int green = (pixel >>  8) & 0xff;
				int blue  = (pixel      ) & 0xff;			
				
				if ( red > hiedge && green > hiedge && blue > hiedge ) {
					result[i] = 0xffffffff;
				} else if ( red < loedge && green < loedge && blue < loedge ) {
					result[i] = 0x0;
				} else {
					result[i] = pixels[i];
				}
				
//				max = Math.max(max, alpha);
//				min = Math.min(min, alpha);
			}
//		    System.out.println( "threshold duration: " + (System.currentTimeMillis() - start) );
			return result;
//		}
	}

	public static int[] getRGB( BufferedImage image, int x, int y, int width, int height, int[] pixels ) {
		int type = image.getType();
		if ( type == BufferedImage.TYPE_INT_ARGB || type == BufferedImage.TYPE_INT_RGB ) {
			return (int [])image.getRaster().getDataElements( x, y, width, height, pixels );
		}
		return image.getRGB( x, y, width, height, pixels, 0, width );
    }

	public static void setRGB( BufferedImage image, int x, int y, int width, int height, int[] pixels ) {
		int type = image.getType();
		if ( type == BufferedImage.TYPE_INT_ARGB || type == BufferedImage.TYPE_INT_RGB ) {
			image.getRaster().setDataElements( x, y, width, height, pixels );
		} else {
			image.setRGB( x, y, width, height, pixels, 0, width );
		}
    }

	public static BufferedImage deepCopy(BufferedImage bi) {
		ColorModel cm = bi.getColorModel();
		boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
		WritableRaster raster = bi.copyData(null);
		return new BufferedImage(cm, raster, isAlphaPremultiplied, null);
	}

    public static ImageData convertToSWT(BufferedImage bufferedImage) {
		if (bufferedImage.getColorModel() instanceof DirectColorModel) {
			DirectColorModel colorModel = (DirectColorModel) bufferedImage.getColorModel();
			PaletteData palette = new PaletteData(colorModel.getRedMask(), colorModel.getGreenMask(), colorModel.getBlueMask());
			ImageData data = new ImageData(bufferedImage.getWidth(), bufferedImage.getHeight(), colorModel.getPixelSize(), palette);
			WritableRaster raster = bufferedImage.getRaster();
			int[] pixelArray = new int[3];
			for (int y = 0; y < data.height; y++) {
				for (int x = 0; x < data.width; x++) {
					raster.getPixel(x, y, pixelArray);
					int pixel = palette.getPixel(new RGB(pixelArray[0],	pixelArray[1], pixelArray[2]));
					data.setPixel(x, y, pixel);
				}
			}
			return data;
		} else if (bufferedImage.getColorModel() instanceof ComponentColorModel) {
			final ComponentColorModel colorModel = (ComponentColorModel)bufferedImage.getColorModel();
			final PaletteData palette = new PaletteData(0xff0000, 0x00ff00,
					0x0000ff);
			final ImageData data = new ImageData(bufferedImage.getWidth(),
					bufferedImage.getHeight(), 24, palette);
			final WritableRaster raster = bufferedImage.getRaster();
			final int size = colorModel.getNumComponents();
			final int[] pixelArray = new int[size];
			if ((size == 1) && (colorModel.getPixelSize() == 48)) {
				for (int y = 0; y < data.height; y++) {
					for (int x = 0; x < data.width; x++) {
						raster.getPixel(x, y, pixelArray);
						// 16 bit greyscale
						data.setPixel(x, y, palette.getPixel(new RGB(
								pixelArray[0] / 256, pixelArray[0] / 256,
								pixelArray[0] / 256)));
					}
				}
			} else if (size == 1) {
				for (int y = 0; y < data.height; y++) {
					for (int x = 0; x < data.width; x++) {
						raster.getPixel(x, y, pixelArray);
						// 8 bit greyscale
						data.setPixel(x, y, palette.getPixel(new RGB(
								pixelArray[0], pixelArray[0], pixelArray[0])));
					}
				}
			} else if (((size == 3) || (size == 4))
					&& (colorModel.getPixelSize() == 48)) {
				for (int y = 0; y < data.height; y++) {
					for (int x = 0; x < data.width; x++) {
						raster.getPixel(x, y, pixelArray);
						// 16 bit color components
						data.setPixel(x, y, palette.getPixel(new RGB(
								pixelArray[0] / 256, pixelArray[1] / 256,
								pixelArray[2] / 256)));
					}
				}
			} else if ((size == 3) || (size == 4)) {
				for (int y = 0; y < data.height; y++) {
					for (int x = 0; x < data.width; x++) {
						raster.getPixel(x, y, pixelArray);
						// 8 bit color components
						data.setPixel(x, y, palette.getPixel(new RGB(
								pixelArray[0], pixelArray[1], pixelArray[2])));
					}
				}
			}
			return data;
		} else if (bufferedImage.getColorModel() instanceof IndexColorModel) {
			IndexColorModel colorModel = (IndexColorModel) bufferedImage.getColorModel();
			int size = colorModel.getMapSize();
			byte[] reds = new byte[size];
			byte[] greens = new byte[size];
			byte[] blues = new byte[size];
			colorModel.getReds(reds);
			colorModel.getGreens(greens);
			colorModel.getBlues(blues);
			RGB[] rgbs = new RGB[size];
			for (int i = 0; i < rgbs.length; i++) {
				rgbs[i] = new RGB(reds[i] & 0xFF, greens[i] & 0xFF,
						blues[i] & 0xFF);
			}
			PaletteData palette = new PaletteData(rgbs);
			ImageData data = new ImageData(bufferedImage.getWidth(), bufferedImage.getHeight(), colorModel.getPixelSize(), palette);
			data.transparentPixel = colorModel.getTransparentPixel();
			WritableRaster raster = bufferedImage.getRaster();
			int[] pixelArray = new int[1];
			for (int y = 0; y < data.height; y++) {
				for (int x = 0; x < data.width; x++) {
					raster.getPixel(x, y, pixelArray);
					data.setPixel(x, y, pixelArray[0]);
				}
			}
			return data;
		}
		return null;
	}

	static BufferedImage convertToAWT(ImageData data) {
		ColorModel colorModel = null;
		PaletteData palette = data.palette;
		if (palette.isDirect) {
			colorModel = new DirectColorModel(data.depth, palette.redMask,
					palette.greenMask, palette.blueMask);
			BufferedImage bufferedImage = new BufferedImage(colorModel,
					colorModel.createCompatibleWritableRaster(data.width,
							data.height), false, null);
			WritableRaster raster = bufferedImage.getRaster();
			int[] pixelArray = new int[3];
			for (int y = 0; y < data.height; y++) {
				for (int x = 0; x < data.width; x++) {
					int pixel = data.getPixel(x, y);
					RGB rgb = palette.getRGB(pixel);
					pixelArray[0] = rgb.red;
					pixelArray[1] = rgb.green;
					pixelArray[2] = rgb.blue;
					raster.setPixels(x, y, 1, 1, pixelArray);
				}
			}
			return bufferedImage;
		} else {
			RGB[] rgbs = palette.getRGBs();
			byte[] red = new byte[rgbs.length];
			byte[] green = new byte[rgbs.length];
			byte[] blue = new byte[rgbs.length];
			for (int i = 0; i < rgbs.length; i++) {
				RGB rgb = rgbs[i];
				red[i] = (byte) rgb.red;
				green[i] = (byte) rgb.green;
				blue[i] = (byte) rgb.blue;
			}
			if (data.transparentPixel != -1) {
				colorModel = new IndexColorModel(data.depth, rgbs.length, red,
						green, blue, data.transparentPixel);
			} else {
				colorModel = new IndexColorModel(data.depth, rgbs.length, red,
						green, blue);
			}
			BufferedImage bufferedImage = new BufferedImage(colorModel,
					colorModel.createCompatibleWritableRaster(data.width,
							data.height), false, null);
			WritableRaster raster = bufferedImage.getRaster();
			int[] pixelArray = new int[1];
			for (int y = 0; y < data.height; y++) {
				for (int x = 0; x < data.width; x++) {
					int pixel = data.getPixel(x, y);
					pixelArray[0] = pixel;
					raster.setPixel(x, y, pixelArray);
				}
			}
			return bufferedImage;
		}
	}
    
	public static void copy(File source, File dest) throws IOException {
		FileChannel in = null, out = null;
		try {
			in = new FileInputStream(source).getChannel();
			out = new FileOutputStream(dest).getChannel();

			long size = in.size();
			MappedByteBuffer buf = in.map(FileChannel.MapMode.READ_ONLY, 0, size);
			out.write(buf);

		} finally {
			if (in != null)
				in.close();
			if (out != null)
				out.close();
		}
	}

	public static void copy(Vector pages, File saveAsDirectory, String name, int width, int height) throws IOException {

		String html = "<html>\n<head>\n" +
		"<style>\n" +
		"/* IMG { width: " + width + "px; height: " + height + "px; } */" + 
		"</style>\n" +
		"</head>\n<body>\n";
		
		int maxPageNumberLength = new String("" + pages.size()).length();
		String pattern = "0000000000".substring(0, maxPageNumberLength);
		DecimalFormat myFormatter = new DecimalFormat(pattern);
		
		int i = 0;
		Iterator ii = pages.iterator();
		while ( ii.hasNext() ) {
			File source = (File)ii.next();
			++i;
			
			String n = source.getName();
			int ix = n.lastIndexOf(".");
			String ext = n.substring(ix);
			
			String fileName = "page" + myFormatter.format(i) + ext;
			
			html += "<img src=\"" + fileName + "\"><br>\n";
			
			File dest = new File(saveAsDirectory, fileName);
			
			copy( source, dest );
		}

		html += "\n</body>\n</html>";
		
		File htmlIndex = new File(saveAsDirectory, "book.htm");
		FileOutputStream fos = new FileOutputStream(htmlIndex);
		PrintStream ps = new PrintStream(fos);
		ps.print(html);
		ps.close();
	}
	
	public final static String formatNumber(long number) {

		final long KILOBYTE = 1L << 10;
		final long MEGABYTE = 1L << 20;
		final long GIGABYTE = 1L << 30;

		String suffix;
		String sub;
		long main;
		if (number > GIGABYTE) {
			main = number / GIGABYTE;
			sub = Long.toString((number % GIGABYTE) / (GIGABYTE / 100));
			suffix = " GB";
		} else if (number > MEGABYTE) {
			main = number / MEGABYTE;
			sub = Long.toString((number % MEGABYTE) / (MEGABYTE / 10000));
			suffix = " MB";
		} else if (number > KILOBYTE) {
			main = number / KILOBYTE;
			sub = Long.toString((number % KILOBYTE) / (KILOBYTE / 100));
			suffix = " KB";
		} else if (number == 1) {
			return "1 byte";
		} else {
			return Long.toString(number) + " bytes";
		}

		if (sub.length() > 2) {
			sub = sub.substring(0, 2);
		}
		if ("0".equals(sub)) {
			sub = "";
		} else if (sub.endsWith("0")) {
			sub = "," + sub.substring(0, 1);
		} else {
			sub = "," + sub;
		}

		return Long.toString(main) + sub + suffix;
	}

	public static BufferedImage readImage(File file, Display display) throws IOException {

		ImageInputStream input = ImageIO.createImageInputStream(file);
		Iterator iter = ImageIO.getImageReaders(input);
		if (iter == null || !iter.hasNext()) {
			Image image = new Image(display, file.getAbsolutePath());
			if (image != null && image.getImageData().height > 0) {
				try {
					return convertToAWT(image.getImageData());
				} catch (Exception e) {
				}
			}
			
			BufferedImage bi = new BufferedImage(200, 300, BufferedImage.TYPE_BYTE_INDEXED);
			Graphics g = bi.getGraphics();
			
			g.setColor( Color.white );
			g.fillRect(0, 0, 200, 300);
			g.setColor( Color.red );
			g.drawString("Image format of", 10, 30);
			g.drawString(file.getName(), 10, 45);
			g.drawString("not supported", 10, 60);
			g.dispose();
			
			return bi;
		}
		ImageReader reader = (ImageReader) iter.next();

		reader.setInput(input);
		String format = reader.getFormatName();

	    if ("JPEG".equalsIgnoreCase(format) || "JPG".equalsIgnoreCase(format)) {
			IIOMetadata metadata = reader.getImageMetadata(0);
			String metadataFormat = metadata.getNativeMetadataFormatName();
			IIOMetadataNode iioNode = (IIOMetadataNode) metadata.getAsTree(metadataFormat);
			NodeList children = iioNode.getElementsByTagName("app14Adobe");
			if (children.getLength() > 0) {
				iioNode = (IIOMetadataNode) children.item(0);
				int transform = Integer.parseInt(iioNode.getAttribute("transform"));
				Raster raster = reader.readRaster(0, reader.getDefaultReadParam());
				if (input != null) {
					input.close();
				}
				reader.dispose();
				return createJPEG4(raster, transform);
			}
		}
	    
		return reader.read(0);
	}

	/**
	 * Java's ImageIO can't process 4-component images
	 * and Java2D can't apply AffineTransformOp either,
	 * so convert raster data to RGB.
	 * Technique due to Mark Stephens.
	 * Free for any use.
	 */
	private static BufferedImage createJPEG4(Raster raster, int xform) {
		
		int w = raster.getWidth();
		int h = raster.getHeight();
		byte[] rgb = new byte[w * h * 3];
		
		// if (Adobe_APP14 and transform==2) then YCCK else CMYK
		if (xform == 2) {// YCCK -- Adobe
			float[] Y = raster.getSamples(0, 0, w, h, 0, (float[]) null);
			float[] Cb = raster.getSamples(0, 0, w, h, 1, (float[]) null);
			float[] Cr = raster.getSamples(0, 0, w, h, 2, (float[]) null);
			float[] K = raster.getSamples(0, 0, w, h, 3, (float[]) null);
			for (int i = 0, imax = Y.length, base = 0; i < imax; i++, base += 3) {
				float k = 220 - K[i], y = 255 - Y[i], cb = 255 - Cb[i], cr = 255 - Cr[i];
				double val = y + 1.402 * (cr - 128) - k;
				val = (val - 128) * .65f + 128;
				rgb[base] = val < 0.0 ? (byte) 0 : val > 255.0 ? (byte) 0xff : (byte) (val + 0.5);
				val = y - 0.34414 * (cb - 128) - 0.71414 * (cr - 128) - k;
				val = (val - 128) * .65f + 128;
				rgb[base + 1] = val < 0.0 ? (byte) 0 : val > 255.0 ? (byte) 0xff : (byte) (val + 0.5);
				val = y + 1.772 * (cb - 128) - k;
				val = (val - 128) * .65f + 128;
				rgb[base + 2] = val < 0.0 ? (byte) 0 : val > 255.0 ? (byte) 0xff : (byte) (val + 0.5);
			}
		} else {
			int[] C = raster.getSamples(0, 0, w, h, 0, (int[]) null);
			int[] M = raster.getSamples(0, 0, w, h, 1, (int[]) null);
			int[] Y = raster.getSamples(0, 0, w, h, 2, (int[]) null);
			int[] K = raster.getSamples(0, 0, w, h, 3, (int[]) null);
			for (int i = 0, imax = C.length, base = 0; i < imax; i++, base += 3) {
				int c = 255 - C[i];
				int m = 255 - M[i];
				int y = 255 - Y[i];
				int k = 255 - K[i];
				float kk = k / 255f;
				rgb[base] = (byte) (255 - Math.min(255f, c * kk + k));
				rgb[base + 1] = (byte) (255 - Math.min(255f, m * kk + k));
				rgb[base + 2] = (byte) (255 - Math.min(255f, y * kk + k));
			}
		}

		raster = Raster.createInterleavedRaster(new DataBufferByte(rgb, rgb.length), w, h, w * 3, 3, new int[] { 0, 1, 2 }, null);
		ColorSpace cs = ColorSpace.getInstance(ColorSpace.CS_sRGB);
		ColorModel cm = new ComponentColorModel(cs, false, true, Transparency.OPAQUE, DataBuffer.TYPE_BYTE);
		return new BufferedImage(cm, (WritableRaster) raster, true, null);
	}
}
