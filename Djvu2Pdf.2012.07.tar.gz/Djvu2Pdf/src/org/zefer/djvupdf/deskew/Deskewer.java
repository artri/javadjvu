package org.zefer.djvupdf.deskew;

import java.awt.Image;
import java.awt.image.PixelGrabber;
import java.io.File;

import javax.imageio.ImageIO;

/*
This file is part of Page Layout Detection Tools.

This code is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this code; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


Ported to Java by zefer|org
*/


public class Deskewer {

	public static void main( String args[] ) {
	
		doTest( "test/0gr.gif" );
		doTest( "test/1gr.gif" );
		doTest( "test/2gr.gif" );
		doTest( "test/3gr.gif" );
		doTest( "test/4gr.gif" );
		doTest( "test/5gr.png" );
		doTest( "test/15gr.gif" );
	}
	
	
	public static void doTest( String name ) {
        System.out.println( name );
		try {
		    // Read from a file
		    File file = new File(name);
		    Image image = ImageIO.read(file);
		    double r = getAngle(image);
	        System.out.println( "r: " + r );
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}


	public static double getAngle( Image image )
			throws InterruptedException {

		int bw = 0;
		byte[] bitfield = null;
		int height = 0;
		int width = 0;
		
		PixelGrabber pg = new PixelGrabber(image, 0, 0, -1, -1, true);

	    if (pg.grabPixels()) {
	    	width = pg.getWidth();
	        height = pg.getHeight();
	        int[] imagePix = (int[])pg.getPixels();
			bw = (width + 7)/8;
			bitfield = toBitField(bw, height, width, imagePix);
	    }

	    if ( height == 0 ) {
		    return 0;
	    }
	    
		Deskewer ds = new Deskewer();
		return ds.findSkew(bitfield, bw, height);
	}

	public static double getAngle(int[] imagePix, int width, int height) throws InterruptedException {

		int bw = 0;
		byte[] bitfield = null;

		bw = (width + 7) / 8;
		bitfield = toBitField(bw, height, width, imagePix);

		Deskewer ds = new Deskewer();
		return ds.findSkew(bitfield, bw, height);
	}


	private static byte[] toBitField(int bw, int height, int width,
			int[] imagePix) {
		byte[] bitfield;
		bitfield = new byte[bw * height];
		for(int j = 0; j < height; j++) {
		    for(int i = 0; i < width; i++) {
		    	int pixel = imagePix[j * width + i];
		    	
		    	short r = (short)((pixel & 0x00ff0000) >> 16);
		    	short g = (short)((pixel & 0x0000ff00) >> 8);
		    	short b = (short)((pixel & 0x000000ff) >> 0);

		    	// luminance formula: x = .299 R + .587 G + .114 B // do we need it?
		    	short avg = (short)((r + g + b)/3);
		    	
		    	int bitbyte = bw * j + i/8; // + (i%8 == 0 ? 0 : 1);
		    	int bitpos = 7 - (i % 8);
		    	byte mask = (byte)(avg < 128 ? 1 : 0);
		    	mask <<= bitpos;
		    	bitfield[bitbyte] |= mask;
		    }	        
		}
		return bitfield;
	}

	private int next_pow2( int n ) {

		int retval = 1;

		while( retval < n ){
	        retval <<= 1;
	    }

		return retval;
	}

	private double findSkew( byte[] img, int width, int height ){
	    int w2 = next_pow2(width);
	    
	    int ssize = (int)(2 * w2 - 1); // Size of sharpness table
	    
	    long[] sharpness = new long[ssize];
	    
	    radon(img, width, height, 1, sharpness);
	    radon(img, width, height, -1, sharpness);
	    
	    int imax = 0;
	    long vmax = 0;
	    double sum = 0.;

	    for( int i = 0; i < ssize; i++ ){
	        long s = sharpness[i];
	        if( s > vmax ){
	            imax = i;
	            vmax = s;
	        }
	        sum += s;
	    }
	    
	    if( vmax <= 3 * sum/height ){  // Heuristics !!!
	        return 0;
	    }
	    
	    int iskew = (int)imax - (int)w2 + 1;
//	    return -57.295779513082320876798154814105 * Math.atan( (double)iskew/(8 * w2) );
	    return Math.atan( (double)iskew/(8 * w2) );
	}

    private void radon(byte[] img, int width, int height, int sign, long sharpness[]) {
        int[] p1_, p2_; // Stored columnwise
        
        int w2 = next_pow2(width);
        int w = width;
        int h = height;

        int s = h * w2;
        
        p1_ = new int[s];
        p2_ = new int[s];
        
        int[] bitcount = BitUtil.bitcount();
        
        for( int ir = 0; ir < h; ir++ ){
            int scl = ir * width;
            for( int ic = 0; ic < w; ic++ ){
                if(sign > 0){
                    p1_[h * ic + ir] = bitcount[(0xff & img[scl + w - 1 - ic])];
                }else{
                    p1_[h * ic + ir] = bitcount[(0xff & img[scl + ic])];
                }
            }
        }

        // Iterate
        int[] x1 = p1_;
        int[] x2 = p2_;
        int step = 1;
        
        for(;;){
            for(int i = 0; i < w2; i += 2 * step){
                for(int j = 0; j<step; j++){
                    // Columns-sources:
                    int s1 = h * (i + j);
                    int s2 = h * (i + j + step);
                    
                    // Columns-targets:
                    int t1 = h * (i + 2 * j);
                    int t2 = h * (i + 2 * j + 1);
                    
                    for(int m = 0; m < h; m++) {
                        x2[t1 + m] = x1[s1 + m];
                        x2[t2 + m] = x1[s1 + m];
                        if(m + j < h){
                            x2[t1 + m] += x1[s2 + m + j];
                        }
                        if(m + j + 1 < h){
                            x2[t2 + m] += x1[s2 + m + j + 1];
                        }
                    }
                }
            }
            // Swap the tables:
            int []aux = x1;
            x1 = x2;
            x2 = aux;
            
            // Increase the step:
            step *= 2;
            if(step >= w2) {
            	break;
            }
        }
        
        // Now, compute the sum of squared finite differences:
        for(int ic = 0; ic < w2; ic++){
            long acc = 0;
            int col = h * ic;
            for(int ir = 0; ir + 1 < h; ir++){
                int diff = (int)(x1[col + ir])-(int)(x1[col + ir + 1]);
                acc += diff * diff;
            }
            sharpness[w2 - 1 + sign * ic] = acc;
        }
    }

	public static class BitUtil {
	    private static BitUtil instance_;
	    private int[] bitcount_;
	    private int[] invbits_;

	    public static int[] bitcount() {
	        if( instance_ == null ){
	            instance_= new BitUtil();
	        }
	        
	        return instance_.bitcount_;
	    }

	    public static int[] invbits(){
	        if( instance_ == null ){
	            instance_ = new BitUtil();
	        }
	        return instance_.invbits_;
	    }

	    public BitUtil() {
	    	
	        bitcount_= new int[256];
	        invbits_= new int[256];
	        
	        for(int i = 0; i < 256; i++){
	            int j = i;
	            int cnt = 0;
	            do{
	                cnt += j & 1;
	            }while( (j >>= 1) != 0 );
	            
	            int x = (byte)(0xff & ((i<<4) | (i>>4)));
	            
	            x = (0xff & ((x & 0xCC)>>2)) | (0xff & ((x & 0x33)<<2));
	            x = (0xff & ((x & 0xAA)>>1)) | (0xff & ((x & 0x55)<<1));

	            bitcount_[i] = cnt;
	            invbits_[i] = x;
	        }
	    }
	}
}
