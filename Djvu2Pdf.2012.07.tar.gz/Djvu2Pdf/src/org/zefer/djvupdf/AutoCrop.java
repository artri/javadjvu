package org.zefer.djvupdf;

public class AutoCrop {
	
	private int height;
	private int width;
	private short[] img;
	private int[] orig;

	public int leftEdge;
	public int rightEdge;
	public int topEdge;
	public int bottomEdge;
	
	private ConversionParameters params;
	
	
	public AutoCrop(int[] imgPixels, int width, int height, int whiteEdge, ConversionParameters params) {
		this.height = height;
		this.width = width;
		this.params = params;
		orig = imgPixels;
		img = new short[orig.length];
		for ( int i = 0; i < orig.length; i++ ) {
	    	int pixel = orig[i];
	    	short r = (short)((pixel & 0x00ff0000) >> 16);
	    	short g = (short)((pixel & 0x0000ff00) >> 8);
	    	short b = (short)((pixel & 0x000000ff) >> 0);
	    	img[i] = (short)(((r + g + b)/3) > 230 - params.hiedge ? 1 : 0);
		}
	}

	public void applyToOriginal() {
		
//		double yprev = 0;
//	    for(int i = 0; i < width; i++) {
//	    	int sum = 0;
//	    	for(int j = 0; j < height; j++) {
//		    	sum += img[j * width + i] > 0 ? 0 : 1;
//		    }	     
//	    	double y = i == 0 ? 0 : 0.3 * sum + (1 - 0.3) * yprev;
//	    	for(int j = 0; j < (int)y; j++) {
//		    	orig[(height - j - 1) * width + i] = 0xff6347;
//		    }	        
//	    	yprev = y;
//		}
//
//	    double xprev = 0;
//    	for(int j = 0; j < height; j++) {
//	    	int sum = 0;
//		    for(int i = leftEdge; i < rightEdge; i++) {
//		    	sum += img[j * width + i] > 0 ? 0 : 1;
//		    }	     
//	    	if (sum < (rightEdge - leftEdge) / 100) {
//	    		sum = 0;
//	    	}
//	    	double x = j == 0 ? 0 : 0.2 * sum + (1 - 0.2) * xprev;
//	    	for(int i = 0; i < (int)x; i++) {
//		    	orig[j * width + i] = 0xff6347;
//		    }	        
//	    	xprev = x;
//		}

    	for ( int i = 0; i < height; i++ ) {
			orig[i * width + leftEdge] = 0xff0000;
		}

		for ( int i = 0; i < height; i++ ) {
			orig[i * width + rightEdge] = 0xff0000;
		}

		for ( int i = 0; i < width; i++ ) {
			orig[topEdge * width + i] = 0xff0000;
		}

		for ( int i = 0; i < width; i++ ) {
			orig[bottomEdge * width + i] = 0xff0000;
		}
	}

	public void process() {
		double yprev = 0;
		int[] xxx = new int[width];
    	int avgy = 0;
    	long all = 0;
    	int ctr = 0;
		
	    for(int i = 0; i < width; i++) {
	    	int sum = 0;

	    	for(int j = 0; j < height; j++) {
		    	sum += img[j * width + i] > 0 ? 0 : 1;
		    }	     
	    	
	    	double y = i == 0 ? sum : 0.3 * sum + (1 - 0.3) * yprev;
	    	xxx[i] = (int)y;
	    	all += (int)y;
	    	if ( sum > 0 ) {
	    		ctr++;
	    	}
	    	yprev = y;
		}
    	avgy = (int)(all / ctr);

	    for(int i = 0; i < width; i++) {
	    	if ( xxx[i] < avgy/4 ) {
	    		xxx[i] = 0;
	    	}
	    }
    	
    	int fill = height/avgy;

    	if ( fill < 20 ) {

    		rightEdge = width;
        	for ( int i = width * 2 / 3; i < width; i++ ) {
    			if ( xxx[i] < avgy/4 && 
    				(i > width - 2 || xxx[i+1] == 0) &&
    				(i > width - 3 || xxx[i+2] == 0) &&
    				(i > width - 4 || xxx[i+3] == 0) &&
    				(i > width - 5 || xxx[i+4] == 0) ) {
    					rightEdge = i;
    					break;
    			}
    		}
        	
        	leftEdge = 0;
        	for ( int i = width / 3; i >= 0; i-- ) {
    			if ( xxx[i] < avgy/4 && 
    				(i < 1 || xxx[i-1] == 0 )&&
    				(i < 2 || xxx[i-2] == 0 ) &&
    				(i < 3 || xxx[i-3] == 0 ) &&
    				(i < 4 || xxx[i-4] == 0 ) ) {
    					leftEdge = i;
    					break;
    			}
    		}
    		
    	} else {

    		boolean found = false;
    		boolean skip = false;
    		int blackCtr = 0;
    		int whiteCtr = 0;
    		rightEdge = width;
        	for ( int i = width - 1; i >= width * 2 / 3; i-- ) {
    			if ( !found && xxx[i] > 0 && 
    				xxx[i-1] > 0 &&
    				xxx[i-2] > 0 &&
    				xxx[i-3] > 0 &&
    				xxx[i-4] > 0 ) {
    					rightEdge = i;
    					found = true;
    			}
    			if ( found && !skip && i > width - 1 - width/12 ) {
    				if( xxx[i] > 0 ) {
    					blackCtr++;
    				} else {
    					whiteCtr++;
    				}
    				
    				if ( whiteCtr > blackCtr ) {
    					found = false;
    					skip = true;
    				}
    			}
    		}
        	
    		found = false;
    		skip = false;
    		blackCtr = 0;
    		whiteCtr = 0;
        	leftEdge = 0;
        	for ( int i = 0 ; i < width / 3; i++ ) {
    			if ( !found && xxx[i] > 0 && 
    				xxx[i+1] > 0 &&
    				xxx[i+2] > 0 &&
    				xxx[i+3] > 0 &&
    				xxx[i+4] > 0 ) {
    					leftEdge = i;
    					found = true;
    			}
    			if ( found && !skip && i < width/12 ) {
    				if( xxx[i] > 0 ) {
    					blackCtr++;
    				} else {
    					whiteCtr++;
    				}
    				
    				if ( whiteCtr > blackCtr ) {
    					found = false;
    					skip = true;
    				}
    			}
    		}
    	}
    	
    	leftEdge = Math.max(0, leftEdge - 5);
    	rightEdge = Math.min(width - 1, rightEdge + 5);
    	
// -----------------------

	    double xprev = 0;
	    int[] yyy = new int[height];
    	int avgx = 0;
    	all = 0;
    	ctr = 0;
    	for(int j = 0; j < height; j++) {
	    	int sum = 0;

		    for(int i = leftEdge; i < rightEdge; i++) {
		    	sum += img[j * width + i] > 0 ? 0 : 1;
		    }	     
	    	
	    	if (sum < (rightEdge - leftEdge) / 100) {
	    		sum = 0;
	    	}
	    	
	    	double x = j == 0 ? sum : 0.2 * sum + (1 - 0.2) * xprev;
	    	
	    	yyy[j] = (int)x;
	    	all += (int)x;
	    	if ( sum > 0 ) {
	    		ctr++;
	    	}
	    	xprev = x;
		}
    	avgx = (int)(all / ctr > 0 ? ctr : 1 );

	    for(int i = 0; i < height; i++) {
	    	if ( yyy[i] < avgx/6 ) {
	    		yyy[i] = 0;
	    	}
	    }
    	
		boolean found = false;
		boolean skip = false;
		int blackCtr = 0;
		int whiteCtr = 0;
		bottomEdge = height - 1;
		boolean completeFill = false;
    	for ( int i = height - 1; i >= height * 2 / 3; i-- ) {
			if ( !found && yyy[i] > 0 && 
					yyy[i-1] > 0 &&
				yyy[i-2] > 0 &&
				yyy[i-3] > 0 &&
				yyy[i-4] > 0 ) {
					bottomEdge = i;
					if ( i == height - 1 ) {
						completeFill = true;
					}
					found = true;
			}
			if ( found && !skip && i > height - 1 - height/12 ) {
				if( yyy[i] > 0 ) {
					blackCtr++;
				} else {
					whiteCtr++;
				}
				
				if ( whiteCtr > blackCtr ) {
					found = false;
					skip = true;
				}
			}
		}

		found = false;
		skip = false;
		blackCtr = 0;
		whiteCtr = 0;
    	topEdge = 0;
    	for ( int i = 0 ; i < height / 3; i++ ) {
			if ( !found && yyy[i] > 0 && 
				yyy[i+1] > 0 &&
				yyy[i+2] > 0 &&
				yyy[i+3] > 0 &&
				yyy[i+4] > 0 ) {
					topEdge = i;
					found = true;
			}
			
			if ( found && !skip && i < height/12 ) {
				if( yyy[i] > 0 ) {
					blackCtr++;
				} else {
					whiteCtr++;
				}
				
				if ( whiteCtr > blackCtr ) {
					found = false;
					skip = true;
				}
			}
		}

		if ( bottomEdge == height - 1 && !completeFill ) {
			bottomEdge = height - topEdge; 
		}

    	leftEdge = Math.max(0, leftEdge - 5 - params.getLeftMargin());
    	rightEdge = Math.min(width - 1, rightEdge + 5 + params.getRightMargin());
    	topEdge = Math.max(0, topEdge - 5 - params.getTopMargin());
    	bottomEdge = Math.min(height - 1, bottomEdge + 5 + params.getBottomMargin());

    	if ( params.proportional ) {
        	int newHeight = bottomEdge - topEdge;
        	int newWidth = rightEdge - leftEdge;
        	
    		double aspect = (double)height/width;
    		double newAspect = (double)newHeight/newWidth;
    		
    		if (aspect/newAspect > 1.02) {
    			int diff = (int)((aspect * newWidth)/1.0) - newHeight;
    			int corr = 0;
    			topEdge -= diff/2;
    			if ( topEdge < 0 ) {
    				corr = topEdge;
    				topEdge = 0;
    			}
    			bottomEdge += diff/2 - corr;
    			if ( bottomEdge > height ) {
    				bottomEdge = height;
    			}
    		} else if (aspect/newAspect < 0.98) {
    			int  diff = (int)(((double)newHeight * 1.0) / aspect) - newWidth;
    			int corr = 0;
    			leftEdge -= diff/2;
    			if ( leftEdge < 0 ) {
    				corr = leftEdge;
    				leftEdge = 0;
    			}
    			rightEdge += diff/2 - corr;
    			if ( rightEdge > width ) {
    				rightEdge = width;
    			}
    		}

//    		newAspect = (double)(Math.max(0, bottomEdge) - Math.max(0, topEdge))/(Math.max(0, rightEdge) - Math.max(0, leftEdge));
//    		System.out.println( "a: " + aspect + ", na: " + newAspect + ", rel: " + (aspect/newAspect) + diag );
    	}
	}
}
