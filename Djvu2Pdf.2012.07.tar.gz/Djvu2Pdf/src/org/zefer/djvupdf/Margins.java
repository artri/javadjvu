package org.zefer.djvupdf;

public class Margins {
	public int left;
	public int right;
	public int top;
	public int bottom;
	
	public Margins clone() {
		Margins copy = new Margins();
		copy.left = left;
		copy.right = right;
		copy.top = top;
		copy.bottom = bottom;
		return copy;
	}
	
	public boolean equals(Margins other) {
		if( other.left == left && other.right == right &&
				other.top == top &&	other.bottom == bottom ) {
			return true;
		} else {
			return false;
		}
	}
}
