package org.zefer.djvupdf;

/* Copyright (c) 2010 the authors listed at the following URL, and/or
the authors of referenced articles or incorporated external code:
http://en.literateprograms.org/Floyd-Steinberg_dithering_(Java)?action=history&offset=20080201121723

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Retrieved from: http://en.literateprograms.org/Floyd-Steinberg_dithering_(Java)?oldid=12476
*/


class RGBTriple {
    public final byte[] channels;
    public RGBTriple() { channels = new byte[3]; }
    public RGBTriple(int R, int G, int B)
    { channels = new byte[]{(byte)R, (byte)G, (byte)B}; }
}


public class FloydSteinbergDither
{
    private static byte plus_truncate_uchar(byte a, int b) {
        if ((a & 0xff) + b < 0)
            return 0;
        else if ((a & 0xff) + b > 255)
            return (byte)255;
        else
            return (byte)(a + b);
    }


    private static byte findNearestColor(RGBTriple color, RGBTriple[] palette) {
        int minDistanceSquared = 255*255 + 255*255 + 255*255 + 1;
        byte bestIndex = 0;
        for (byte i = 0; i < palette.length; i++) {
            int Rdiff = (color.channels[0] & 0xff) - (palette[i].channels[0] & 0xff);
            int Gdiff = (color.channels[1] & 0xff) - (palette[i].channels[1] & 0xff);
            int Bdiff = (color.channels[2] & 0xff) - (palette[i].channels[2] & 0xff);
            int distanceSquared = Rdiff*Rdiff + Gdiff*Gdiff + Bdiff*Bdiff;
            if (distanceSquared < minDistanceSquared) {
                minDistanceSquared = distanceSquared;
                bestIndex = i;
            }
        }
        return bestIndex;
    }


	public static byte[][] floydSteinbergDither(RGBTriple[][] image, RGBTriple[] palette) {
		byte[][] result = new byte[image.length][image[0].length];

		for (int y = 0; y < image.length; y++) {
			for (int x = 0; x < image[y].length; x++) {
				RGBTriple currentPixel = image[y][x];
				byte index = findNearestColor(currentPixel, palette);
				result[y][x] = index;

				for (int i = 0; i < 3; i++) {
					int error = (currentPixel.channels[i] & 0xff) - (palette[index].channels[i] & 0xff);
					if (x + 1 < image[0].length) {
						image[y + 0][x + 1].channels[i] = plus_truncate_uchar(image[y + 0][x + 1].channels[i],(error * 7) >> 4);
					}
					if (y + 1 < image.length) {
						if (x - 1 > 0) {
							image[y + 1][x - 1].channels[i] = plus_truncate_uchar(image[y + 1][x - 1].channels[i], (error * 3) >> 4);
						}
						image[y + 1][x + 0].channels[i] = plus_truncate_uchar(image[y + 1][x + 0].channels[i], (error * 5) >> 4);
						if (x + 1 < image[0].length) {
							image[y + 1][x + 1].channels[i] = plus_truncate_uchar(image[y + 1][x + 1].channels[i],(error * 1) >> 4);
						}
					}

				}
			}
		}

		return result;
	}

    public static int[] dither ( int[] pixels, int width ) {

        RGBTriple[][] image = new RGBTriple[pixels.length/width][width];
    	

        for (int y = 0; y < image.length; y++) {
            for (int x = 0; x < image[0].length; x++) {
				int pixel = pixels[y * width + x];
				int red   = (pixel >> 16) & 0xff;
				int green = (pixel >>  8) & 0xff;
				int blue  = (pixel      ) & 0xff;			
            	image[y][x] = new RGBTriple(red, green, blue);
            }
        }

        RGBTriple[] palette = {
                new RGBTriple(0, 0, 0),
                new RGBTriple(47, 47, 47),
                new RGBTriple(87, 87, 87),
                new RGBTriple(127, 127, 127),
                new RGBTriple(255, 255, 255),
            };

        byte[][] r = floydSteinbergDither(image, palette);
        
    	int[] result = new int[pixels.length];
        for (int y = 0; y < r.length; y++) {
            for (int x = 0; x < r[0].length; x++) {
            	byte[] channels = palette[r[y][x]].channels;
				result[y * width + x] = (0xff0000 & ((int)channels[0] << 16)) + (0xff00 & ((int)channels[1] << 8)) + channels[2];
            }
        }
    	
    	return result;
    }
}

