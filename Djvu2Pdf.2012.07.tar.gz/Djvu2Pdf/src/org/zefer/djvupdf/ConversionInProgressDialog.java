package org.zefer.djvupdf;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.TimeZone;
import java.util.Vector;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.FileImageOutputStream;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;
import org.zefer.djvupdf.Book.BookPage;
import org.zefer.djvupdf.deskew.Deskewer;
import org.zefer.djvupdf.filter.TextEdgesFilter;

import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfString;
import com.itextpdf.text.pdf.PdfWriter;

public class ConversionInProgressDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	protected ProgressBar bar;
	protected Button cancelButton;
	protected Button saveAsPdfButton;
	protected Button saveAsImagesButton;
	protected Button viewButton;

	private DjvuConverter main;
	
	private boolean stopExport;
	private RunExport exportThread;
	private Label progressLabel;
	
	private File resultPdf;
	
	Vector pages = new Vector();
	
	private int from;
	private int to;
	
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public ConversionInProgressDialog(Shell parent, DjvuConverter main, int from, int to) {
		super(parent);
		this.main = main;
		this.from = from-1;
		this.to = to;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();

		stopExport = false;
		exportThread = new RunExport();
		exportThread.start();
		
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {

		shell = new Shell(getParent(), SWT.TITLE | SWT.PRIMARY_MODAL);
		shell.setSize(528, 129);
		shell.setText("eBook generation in progress");
		shell.setLayout(new FormLayout());
		
        org.eclipse.swt.graphics.Rectangle shellBounds = main.shell.getBounds();
        Point dialogSize = shell.getSize();

        shell.setLocation(
          shellBounds.x + (shellBounds.width - dialogSize.x) / 2,
          shellBounds.y + (shellBounds.height - dialogSize.y) / 2);		
		
		bar = new ProgressBar(shell, SWT.NONE);
		bar.setMaximum(main.getExpectedNumberOfPages(from, to));

		FormData fd_progressBar = new FormData();
		fd_progressBar.top = new FormAttachment(0, 21);
		fd_progressBar.left = new FormAttachment(0, 10);
		fd_progressBar.right = new FormAttachment(100, -10);
		bar.setLayoutData(fd_progressBar);
		
		cancelButton = new Button(shell, SWT.NONE);
		cancelButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if ( !stopExport ) {
					stopExport = true;
				} else {
					shell.dispose();
				}
			}
		});

		FormData fd_btnCancel = new FormData();
		fd_btnCancel.right = new FormAttachment(100, -10);
		fd_btnCancel.bottom = new FormAttachment(100, -10);
		cancelButton.setLayoutData(fd_btnCancel);
		cancelButton.setText("Cancel");
		
		saveAsPdfButton = new Button(shell, SWT.NONE);
		saveAsPdfButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog fd = new FileDialog(shell, SWT.SAVE | SWT.APPLICATION_MODAL);
		    	
		    	fd.setText("Save PDF eBook as...");
		    	fd.setFilterExtensions(new String[] {"*.pdf"});
		    	fd.setFilterNames(new String[] {"PDF Document (*.pdf)"});
		    	fd.setFilterIndex(0);
		    	
				if (main.recentSaveDirectory != null) {
					fd.setFilterPath(main.recentSaveDirectory);
				}
				String saveAs = fd.open();
				
				if ( saveAs != null ) {
					if ( !saveAs.toLowerCase().endsWith(".pdf") ) {
						saveAs += ".pdf";
					}
					
					File saveAsFile = new File( saveAs );
					main.recentSaveDirectory = saveAsFile.getParent();

					boolean doit = false;
					if (saveAsFile.exists()) {
						MessageBox mb = new MessageBox(fd.getParent(), SWT.ICON_WARNING | SWT.YES | SWT.NO);
						mb.setMessage(saveAs + " already exists. Do you want to replace it?");
						doit = mb.open() == SWT.YES;
					} else {
						doit = true;
					}

					if ( doit ) {
						try {
							Util.copy(resultPdf, saveAsFile);
						} catch (IOException e1) {
							e1.printStackTrace();
							MessageBox mb = new MessageBox(fd.getParent(), SWT.ICON_WARNING | SWT.CANCEL);
							mb.setMessage(saveAs + " is not writable");
							mb.open();
						}
					}
				}
			}
		});
		
		saveAsPdfButton.setEnabled(false);
		FormData fd_btnSaveAs = new FormData();
		fd_btnSaveAs.top = new FormAttachment(cancelButton, 0, SWT.TOP);
		fd_btnSaveAs.right = new FormAttachment(cancelButton, -6);
		saveAsPdfButton.setLayoutData(fd_btnSaveAs);
		saveAsPdfButton.setText("Save PDF...");
		
		saveAsImagesButton = new Button(shell, SWT.NONE);
		saveAsImagesButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				DirectoryDialog fd = new DirectoryDialog(shell, SWT.SAVE | SWT.APPLICATION_MODAL);
		    	
		    	fd.setText("Save pages as images to...");
		    	
				if (main.recentSaveDirectory != null) {
					fd.setFilterPath(main.recentSaveDirectory);
				}
				String saveAs = fd.open();
				
				if ( saveAs != null ) {
					File saveAsDirectory = new File( saveAs );
					main.recentSaveDirectory = saveAsDirectory.getParent();

					
			        if (saveAsDirectory.isDirectory() && saveAsDirectory.canWrite()) {
			            String[] files = saveAsDirectory.list();
						boolean doit = false;
			            if (files.length > 0) {
							MessageBox mb = new MessageBox(fd.getParent(), SWT.ICON_WARNING | SWT.YES | SWT.NO);
							mb.setMessage(saveAs + " is not empty. Do you want to proceed?");
							doit = mb.open() == SWT.YES;
						} else {
							doit = true;
						}

						if ( doit ) {
							try {
								Util.copy(pages, saveAsDirectory, main.activeDocument, main.deviceWidth, main.deviceHeight );
							} catch (IOException e1) {
								e1.printStackTrace();
							}
						}
			        } else {
						MessageBox mb = new MessageBox(fd.getParent(), SWT.ICON_WARNING | SWT.CANCEL);
						mb.setMessage(saveAs + " is not a directory or not writable");
						mb.open();
			        }
				}
			}
		});
		
		saveAsImagesButton.setEnabled(false);
		fd_btnSaveAs = new FormData();
		fd_btnSaveAs.top = new FormAttachment(cancelButton, 0, SWT.TOP);
		fd_btnSaveAs.right = new FormAttachment(saveAsPdfButton, -6);
		saveAsImagesButton.setLayoutData(fd_btnSaveAs);
		saveAsImagesButton.setText("Save images...");
		
		viewButton = new Button(shell, SWT.NONE);
		viewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
//		        String params = "open /Applications/Safari.app " + resultPdf.getAbsolutePath();
		        try {
//					Runtime.getRuntime().exec(params);
					org.eclipse.swt.program.Program.launch("file:" + resultPdf.getAbsolutePath());				
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				
			}
		});
		viewButton.setEnabled(false);
		FormData fd_btnView = new FormData();
		fd_btnView.top = new FormAttachment(cancelButton, 0, SWT.TOP);
		fd_btnView.right = new FormAttachment(saveAsImagesButton, -6);
		viewButton.setLayoutData(fd_btnView);
		viewButton.setText("View");
		
		progressLabel = new Label(shell, SWT.NONE);
		FormData fd_progressLabel = new FormData();
		fd_progressLabel.top = new FormAttachment(bar, 12);
		fd_progressLabel.left = new FormAttachment(0, 10);
		fd_progressLabel.right = new FormAttachment(0, 279);
		progressLabel.setLayoutData(fd_progressLabel);
	}

	public void setProgress( int value, long elapsed ) {
		final int v = value;
		final long speed = elapsed / (value == 0 ? 1 : value);
		
		if ( bar == null || bar.isDisposed() ) {
			return;
		}
		
		shell.getDisplay().asyncExec(new Runnable() {
            public void run() {
              if (bar.isDisposed()) {
                  return;
              }
              bar.setSelection(v);
              final long remain = (bar.getMaximum() - v) * speed;
              
              DateFormat df = new SimpleDateFormat("HH:mm:ss");
              df.setTimeZone(TimeZone.getTimeZone("GMT+0"));
              
              progressLabel.setText( "Page " + v + " of " + bar.getMaximum() + ", ETA: " + df.format(new Date(remain)) );
            }
          });
	}

	public void setProgress( final String append, final long elapsed ) {
		
		if ( bar == null || bar.isDisposed() ) {
			return;
		}
		
		shell.getDisplay().asyncExec(new Runnable() {
            public void run() {
              if (bar.isDisposed()) {
                  return;
              }
              String last = progressLabel.getText();
              int ind = last.indexOf(",");
              if ( ind > 0 ) {
            	  last = last.substring(0, ind);
              }

              DateFormat df = new SimpleDateFormat("HH:mm:ss");
              df.setTimeZone(TimeZone.getTimeZone("GMT+0"));

              progressLabel.setText( last + append + ", Elapsed: " + df.format(new Date(elapsed)) );
            }
          });
	}

	private void done(final long elapsed) {

		if ( cancelButton.isDisposed() ) {
			return;
		}
		
		shell.getDisplay().asyncExec(new Runnable() {
            public void run() {
              if (cancelButton.isDisposed()) {
                  return;
              }
              cancelButton.setText("Close");
              saveAsPdfButton.setEnabled(true);
              saveAsImagesButton.setEnabled(true);
              viewButton.setEnabled(true);
              bar.redraw();
            }
        });

		setProgress(", " + Util.formatNumber(resultPdf.length()), elapsed);
	    stopExport = true;
	}
	
	public class RunExport extends Thread {

		public void run() {

			long start = System.currentTimeMillis();
			
			try {

				com.itextpdf.text.Rectangle format = new com.itextpdf.text.Rectangle(main.deviceWidth, main.deviceHeight);
				
				com.itextpdf.text.Document document = new com.itextpdf.text.Document(format, 0, 0, 0, 0);

				resultPdf = File.createTempFile("djvu", ".pdf");
				resultPdf.deleteOnExit();
				
			    PdfWriter pdfwriter = PdfWriter.getInstance(document, new FileOutputStream(resultPdf));
			    pdfwriter.setCompressionLevel(0);
			    pdfwriter.setViewerPreferences(PdfWriter.PageLayoutSinglePage);
			    document.open();
			    
			    PdfDictionary dic = pdfwriter.getInfo();
			    dic.put(PdfName.CREATOR, new PdfString("DJVU to PDF eBook converter. http://pd4ml.com/djvu.htm", PdfObject.TEXT_UNICODE));
			    dic.put(PdfName.TITLE, new PdfString(main.book.getTitle(), PdfObject.TEXT_UNICODE));
			    dic.put(PdfName.AUTHOR, new PdfString(main.book.getAuthor(), PdfObject.TEXT_UNICODE));

			    int pageCounter = 1;
			    
				start = System.currentTimeMillis();
				
				for ( int i = from; i < to; i++ ) {

					ConversionParameters pageParams = main.getPageParameters(i);
					if (pageParams == null) {
						continue;
					}

					BookPage page = main.book.getPage(i, pageParams.split, pageParams.imageScale, shell.getDisplay(), false);
					
					BufferedImage bimg;
					
					bimg = prepareImage(i, pageParams, page, main);

					String imgType = "jpeg";
					String imgExt = ".jpg";
					
					if ( pageParams.imageType > 1 ) {
						imgType = "png";
						imgExt = ".png";
					}
					
					Iterator iter = ImageIO.getImageWritersByFormatName(imgType);
					ImageWriter writer;
					ImageWriteParam iwp;
					
					switch(pageParams.imageType) {
					case 2:
					case 3:
						writer = (ImageWriter)iter.next();
						iwp = writer.getDefaultWriteParam();
						break;
					default:
						iter = ImageIO.getImageWritersByFormatName(imgType);
						writer = (ImageWriter)iter.next();
						iwp = writer.getDefaultWriteParam();
						iwp.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
						iwp.setCompressionQuality((float)pageParams.jpegQual);
					}
					
					File file = File.createTempFile("spool", imgExt );
					file.deleteOnExit();
					
					if ( pageParams.split ) {

						BufferedImage secondImage = writeFirstImageOfPair(pageParams, file, bimg, writer, iwp, main);

						com.itextpdf.text.Image img = com.itextpdf.text.Image.getInstance(file.getAbsolutePath());
				        img.setAbsolutePosition(0,0);
				        img.scaleAbsolute(format.getWidth(), format.getHeight());
					    pdfwriter.getDirectContent().addImage(img, true);

						pageCounter++;
//						setProgress(pageCounter, System.currentTimeMillis() - start);
					    
					    document.newPage();

						pages.addElement(file);
					    
						file = File.createTempFile("spool", imgExt );
						file.deleteOnExit();
						
						FileImageOutputStream output = new FileImageOutputStream(file);
						writer.setOutput(output);
						IIOImage image = new IIOImage(secondImage, null, null);
						writer.write(null, image, iwp);
						writer.dispose();

						img = com.itextpdf.text.Image.getInstance(file.getAbsolutePath());
				        img.setAbsolutePosition(0,0);
				        img.scaleAbsolute(format.getWidth(), format.getHeight());
					    pdfwriter.getDirectContent().addImage(img, true);

						setProgress(pageCounter++, System.currentTimeMillis() - start);
						
					    document.newPage();

						pages.addElement(file);
						
					} else {

						writeSingleImage(pageParams, file, bimg, writer, iwp, main);

						com.itextpdf.text.Image img = com.itextpdf.text.Image.getInstance(file.getAbsolutePath());
				        img.setAbsolutePosition(0,0);
				        img.scaleAbsolute(format.getWidth(), format.getHeight());
					    pdfwriter.getDirectContent().addImage(img, true);

					    setProgress(pageCounter++, System.currentTimeMillis() - start);

					    document.newPage();

						pages.addElement(file);
					}
					
					if ( stopExport ) {
						break;
					}
				}

			    document.close();
			    
//				for ( int i = 0; i < main.totalPages; i++ ) {
//					String ix = "00000".substring((""+i).length()) + i;
//					File fx = new File( "spool/" + ix + ".jpg" );
//					fx.delete();
//					if ( main.split ) {
//						fx = new File( "spool/" + ix + "a.jpg" );
//						fx.delete();
//					}
//				}

				done(System.currentTimeMillis() - start);
				
			} catch (Exception e ) {
				e.printStackTrace();
				done(System.currentTimeMillis() - start);
			}
		}
	}

	public static void writeSingleImage(ConversionParameters pageParams, File file,
			BufferedImage bimg, ImageWriter writer, ImageWriteParam iwp, DjvuConverter main) throws IOException, FileNotFoundException {
		
		int type = BufferedImage.TYPE_INT_RGB;
		switch ( pageParams.imageType ) {
		case 0:
			type = BufferedImage.TYPE_BYTE_GRAY;
			break;
		case 3:
			type = BufferedImage.TYPE_BYTE_INDEXED;
		}
		
		BufferedImage scaledImage = new BufferedImage((int)(main.deviceWidth * pageParams.imageScale), (int)(main.deviceHeight * pageParams.imageScale), type);
		Graphics2D graphics2D = scaledImage.createGraphics();
		AffineTransform xform = AffineTransform.getScaleInstance((double) main.deviceWidth * pageParams.imageScale / bimg.getWidth(), (double) (main.deviceHeight * pageParams.imageScale)/ bimg.getHeight());
		graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		graphics2D.drawImage(bimg, xform, null);
		graphics2D.dispose();
		
		int[] scaledPagePixels = new int[(int)(main.deviceWidth * pageParams.imageScale * main.deviceHeight * pageParams.imageScale)]; 
		PixelGrabber pg = new PixelGrabber(scaledImage, 0, 0, (int)(main.deviceWidth * pageParams.imageScale), (int)(main.deviceHeight * pageParams.imageScale), scaledPagePixels, 0, (int)(main.deviceWidth * pageParams.imageScale));
		try {
			pg.grabPixels();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// 			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		
		int[] processed = Util.copyAndProcess(scaledPagePixels, 
				(int)(main.deviceWidth * pageParams.imageScale), 
				(int)(main.deviceHeight * pageParams.imageScale), 
				255 - pageParams.hiedge, pageParams.loedge, pageParams.edgeFilter);

		BufferedImage resultingImage = new BufferedImage((int)(main.deviceWidth * pageParams.imageScale), (int)(main.deviceHeight * pageParams.imageScale), type);
		resultingImage.setRGB(0, 0, (int)(main.deviceWidth * pageParams.imageScale), (int)(main.deviceHeight * pageParams.imageScale), processed, 0, (int)(main.deviceWidth * pageParams.imageScale));
		
		FileImageOutputStream output = new FileImageOutputStream(file);
		writer.setOutput(output);
		IIOImage image = new IIOImage(resultingImage, null, null);
		writer.write(null, image, iwp);
		writer.dispose();
	}

	public static BufferedImage writeFirstImageOfPair(ConversionParameters pageParams, File file,
			BufferedImage bimg, ImageWriter writer, ImageWriteParam iwp, DjvuConverter main) throws IOException, FileNotFoundException {

		int type = BufferedImage.TYPE_INT_RGB;
		switch ( pageParams.imageType ) {
		case 0:
			type = BufferedImage.TYPE_BYTE_GRAY;
			break;
		case 3:
			type = BufferedImage.TYPE_BYTE_INDEXED;
		}
		
		BufferedImage scaledImage = new BufferedImage((int)(main.deviceHeight * pageParams.imageScale), (int)(main.deviceWidth * pageParams.imageScale * 2), type);
		Graphics2D graphics2D = scaledImage.createGraphics();
		AffineTransform xform = AffineTransform.getScaleInstance((double) main.deviceHeight * pageParams.imageScale / bimg.getWidth(), (double) main.deviceWidth * pageParams.imageScale * 2 / bimg.getHeight());
		graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		graphics2D.drawImage(bimg, xform, null);
		graphics2D.dispose();
		
		int[] scaledPagePixels = new int[(int)(main.deviceWidth * main.deviceHeight * 2 * pageParams.imageScale * pageParams.imageScale)]; 
		PixelGrabber pg = new PixelGrabber(scaledImage, 0, 0, (int)(main.deviceHeight * pageParams.imageScale), (int)(main.deviceWidth * pageParams.imageScale * 2 + 20), scaledPagePixels, 0, (int)(main.deviceHeight * pageParams.imageScale));
		try {
			pg.grabPixels();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		int[] processed = Util.copyAndProcess(scaledPagePixels, 
				(int)(main.deviceHeight * pageParams.imageScale), 
				(int)(main.deviceWidth * pageParams.imageScale * 2), 
				255 - pageParams.hiedge, pageParams.loedge, pageParams.edgeFilter);
		
		int split = Util.getSplitPosition(processed, (int)(main.deviceHeight * pageParams.imageScale), (int)(main.deviceWidth * pageParams.imageScale * 2), 20);

		int[] imageBytes = Util.rotate(processed, (int)(main.deviceHeight * pageParams.imageScale), split, true);
		BufferedImage resultingImage1 = new BufferedImage(split, (int)(main.deviceHeight * pageParams.imageScale), type);
		resultingImage1.setRGB(0, 0, split, (int)(main.deviceHeight * pageParams.imageScale), imageBytes, 0, split);

		imageBytes = Util.rotate(processed, (int)(main.deviceHeight * pageParams.imageScale), split, false);
		BufferedImage resultingImage2 = new BufferedImage((int)(main.deviceWidth * pageParams.imageScale * 2 - split), (int)(main.deviceHeight * pageParams.imageScale), type);
		resultingImage2.setRGB(0, 0, (int)(main.deviceWidth * pageParams.imageScale * 2 - split), (int)(main.deviceHeight * pageParams.imageScale), imageBytes, 0, (int)(main.deviceWidth * pageParams.imageScale * 2 - split));
		
		FileImageOutputStream output = new FileImageOutputStream(file);
		writer.setOutput(output);
		IIOImage image = new IIOImage(resultingImage1, null, null);
		writer.write(null, image, iwp);
		return resultingImage2;
	}
	
	public static BufferedImage prepareImage(int i, ConversionParameters pageParams,
			BookPage page, DjvuConverter main) throws InterruptedException {
		BufferedImage bimg;

		int type = BufferedImage.TYPE_INT_RGB;
		switch ( pageParams.imageType ) {
		case 0:
			type = BufferedImage.TYPE_BYTE_GRAY;
			break;
		case 3:
			type = BufferedImage.TYPE_BYTE_INDEXED;
		}
		
		if ( pageParams.autocrop ) {

			int currentPageWidth = page.width; // wx
			int currentPageHeight = page.height; // hx
			int[] currentPagePixels = Arrays.copyOf(page.data, page.data.length);

			if( pageParams.edgeFilter ) {
				TextEdgesFilter.filterText( currentPagePixels, currentPageWidth, currentPageHeight, 40, 130, .1f, .8f );
			}
			
			double angle = 0;
			Double agl = (Double)main.angles.get("" + i);
			if ( agl == null ) {
				angle = Deskewer.getAngle(currentPagePixels, currentPageWidth, currentPageHeight);
			    if ( angle < .01 && angle > -.01 ) {
			    	angle = 0;
			    }
			    
			    main.angles.put("" + i, new Double(angle));
			} else {
				angle = agl.doubleValue();
			}

			bimg = new BufferedImage(currentPageWidth, currentPageHeight, type);
			try {
				bimg.setRGB(0, 0, currentPageWidth, currentPageHeight, currentPagePixels, 0, currentPageWidth);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		    
		    if ( angle != 0 ) {
		    	BufferedImage rotatedImage = new BufferedImage(currentPageWidth, currentPageHeight, type);
		    	Graphics2D graphics2D = rotatedImage.createGraphics();
		    	AffineTransform xform = AffineTransform.getRotateInstance(angle);
		    	graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		    	graphics2D.setColor(Color.white);
		    	graphics2D.fillRect(0, 0, currentPageWidth, currentPageHeight);
		    	graphics2D.drawImage(bimg, xform, null);
		    	graphics2D.dispose();
		    	bimg = rotatedImage;
		    }
			
			int[] straightImage = new int[currentPageWidth * currentPageHeight]; 
			PixelGrabber pg = new PixelGrabber(bimg, 0, 0, currentPageWidth, currentPageHeight, straightImage, 0, currentPageWidth);
			try {
				pg.grabPixels();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		    
		    AutoCrop ac = new AutoCrop(straightImage, currentPageWidth, currentPageHeight, 110, pageParams);
		    ac.process();
			
			int x = ac.leftEdge;
			int y = ac.topEdge;
			int w = ac.rightEdge - x;
			int h = ac.bottomEdge - y;
			
			bimg = new BufferedImage(w, h, type);
			try {
				bimg.setRGB(0, 0, w, h, straightImage, y * currentPageWidth + x, currentPageWidth);
			} catch (Exception e1) {
				System.out.println( currentPageWidth + "," + currentPageHeight );
				System.out.println( x + "," + y + "," + w + "," + h );
				e1.printStackTrace();
			}

		} else {

			int wx = page.width;
			int hx = page.height;
			int [] pixels = Arrays.copyOf(page.data, page.data.length);

			if( pageParams.edgeFilter ) {
				TextEdgesFilter.filterText( pixels, wx, hx, 40, 130, .1f, .8f );
			}
			
			int x = pageParams.getLeftMargin();
			int y = pageParams.getTopMargin();
			int w = wx - pageParams.getLeftMargin() - pageParams.getRightMargin();
			int h = hx - pageParams.getTopMargin() - pageParams.getBottomMargin();
			
			Util.clean(pixels, 256 - pageParams.hiedge, pageParams.loedge);				

			bimg = new BufferedImage(w, h, type);
			try {
				bimg.setRGB(0, 0, w, h, pixels, y * wx + x, wx);
			} catch (Exception e1) {
				System.out.println( wx + "," + hx );
				System.out.println( x + "," + y + "," + w + "," + h );
				e1.printStackTrace();
			}
		}
		return bimg;
	}
}
