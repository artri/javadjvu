package org.zefer.djvupdf;

import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class PaperFormat {

	public String name;
	public int height;
	public int width;
	public boolean custom;

	public static PaperFormat[] namedFormats = {
//		new PaperFormat("A4", 595, 842 ),
//		new PaperFormat("Letter", 612, 792 ),
//		new PaperFormat("Custom", 456, 600, true ),
	};
	
	public PaperFormat( String name, int width, int height, boolean custom ) {
		this( name, width, height );
		this.custom = custom;
	}
	
	public PaperFormat( String name, int width, int height ) {
		this.name = name;
		this.height = height;
		this.width = width;
	}
	
	public static void readProperties( Properties p ) {
		Vector v = new Vector();
		for ( int i = 0; i < 40; i++ ) {
			String def = p.getProperty("device." + i );
			if ( def != null ) {
				StringTokenizer st = new StringTokenizer(def, ",");
				if ( st.countTokens() > 2 ) {
					String name = st.nextToken();
					String width = st.nextToken();
					String height = st.nextToken(); 
					try {
						PaperFormat pf = new PaperFormat(name, Integer.parseInt(width), Integer.parseInt(height));
						v.addElement(pf);
					} catch (NumberFormatException e) {
					}
				}
			}
		}

		PaperFormat pf = new PaperFormat("Custom", 480, 640, true);
		v.addElement(pf);

		namedFormats = new PaperFormat[v.size()];
		for ( int i = 0; i < v.size(); i++ ) {
			namedFormats[i] = (PaperFormat)v.elementAt(i);
		}
	}
		
	public static void saveProperties( Properties p ) {
		for ( int i = 0; i < namedFormats.length; i++ ) {
			if( !namedFormats[i].custom ) {
				p.setProperty("device." + i, namedFormats[i].name + "," + namedFormats[i].width + "," + namedFormats[i].height );
			}
		}
	}
	
	public static boolean isCustomFormat( String name ) {
		for ( int i = 0; i < namedFormats.length; i++ ) {
			if(namedFormats[i].name.equals(name)) {
				return namedFormats[i].custom;
			}
		}
		return true;
	}

	public static PaperFormat getFormat( int w, int h ) {
		for ( int i = 0; i < namedFormats.length; i++ ) {
			if(namedFormats[i].width == w && namedFormats[i].height == h) {
				return namedFormats[i];
			}
		}
		return null;
	}
	
	public static PaperFormat getFormat( String name ) {
		for ( int i = 0; i < namedFormats.length; i++ ) {
			if(namedFormats[i].name.equals(name)) {
				return namedFormats[i];
			}
		}
		return null;
	}
}
