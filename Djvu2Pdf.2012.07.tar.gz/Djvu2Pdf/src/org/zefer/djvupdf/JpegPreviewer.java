package org.zefer.djvupdf;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;
import org.zefer.djvupdf.Book.BookPage;

import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfString;
import com.itextpdf.text.pdf.PdfWriter;

public class JpegPreviewer extends Dialog {

	protected Object result;
	protected Shell shlJpegQuality;
	private DjvuConverter main;
	private ConversionParameters params;
	
	private Label whiteEdgeLabel;
	private Label blackEdgeLabel;
	private Label lblMedianFilter;
	private Label imageSize;
	private Label bookSize;
	private Label numberOfPages;
	private Label displayTarget;
	private Label lblJpegQuality;
	private Spinner jpegQualitySpinner;
	private ScrolledComposite scrolledComposite;
	
	private BufferedImage bimg;
	
	private File imageFile; 
	private BookPage page;

	long jpegSize;
	
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public JpegPreviewer(Shell parent, DjvuConverter main, ConversionParameters params) {
		super(parent);
		this.main = main;
		this.params = params;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shlJpegQuality.open();
		shlJpegQuality.layout();
		Display display = getParent().getDisplay();
		while (!shlJpegQuality.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shlJpegQuality = new Shell(getParent(), SWT.BORDER | SWT.RESIZE | SWT.TITLE | SWT.PRIMARY_MODAL);
		shlJpegQuality.setSize(728, 548);
		shlJpegQuality.setText("Image Quality");
		shlJpegQuality.setLayout(new FormLayout());
		
        org.eclipse.swt.graphics.Rectangle shellBounds = main.shell.getBounds();
        Point dialogSize = shlJpegQuality.getSize();

        shlJpegQuality.setLocation(
          shellBounds.x + (shellBounds.width - dialogSize.x) / 2,
          shellBounds.y + (shellBounds.height - dialogSize.y) / 2);		
		
		
		Composite composite = new Composite(shlJpegQuality, SWT.NONE);
		FormData fd_composite = new FormData();
		fd_composite.width = 250;
		fd_composite.top = new FormAttachment(0, 10);
		fd_composite.right = new FormAttachment(100, -10);
		fd_composite.bottom = new FormAttachment(100, -40);
		composite.setLayoutData(fd_composite);
		
		scrolledComposite = new ScrolledComposite(shlJpegQuality, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		FormData fd_scrolledComposite = new FormData();
		fd_scrolledComposite.top = new FormAttachment(0, 10);
		fd_scrolledComposite.left = new FormAttachment(0, 10);
		fd_scrolledComposite.bottom = new FormAttachment(100, -40);
		fd_scrolledComposite.right = new FormAttachment(composite, -6);
		
		displayTarget = new Label(scrolledComposite, SWT.CENTER);
		displayTarget.setBackground(shlJpegQuality.getDisplay().getSystemColor(SWT.COLOR_GRAY));
		scrolledComposite.setContent(displayTarget);
		
		Combo imageTypeCombo = new Combo(composite, SWT.READ_ONLY);
		imageTypeCombo.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				params.imageType = ((Combo)e.widget).getSelectionIndex();
				updateGUI(true);
			}
		});
		imageTypeCombo.setItems(new String[] {"JPEG Grayscale", "JPEG", "PNG-24", "PNG-8" });
		imageTypeCombo.setVisibleItemCount(4);
		imageTypeCombo.setBounds(112, 8, 119, 22);
		imageTypeCombo.select(params.imageType);
		
		jpegQualitySpinner = new Spinner(composite, SWT.BORDER);
		jpegQualitySpinner.setBounds(112, 49, 51, 22);
		jpegQualitySpinner.setDigits(2);
		jpegQualitySpinner.setMinimum(10);
		jpegQualitySpinner.setMaximum(300);
		jpegQualitySpinner.setIncrement(10);
		jpegQualitySpinner.setSelection((int)(params.jpegQual * 100));
		jpegQualitySpinner.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
		        int selection = jpegQualitySpinner.getSelection();
		        int digits = jpegQualitySpinner.getDigits();
		        params.jpegQual = (selection / Math.pow(10, digits)); 
		        updateGUI(false);
			}
		});
		
		final Spinner imageScaleSpinner = new Spinner(composite, SWT.BORDER);
		imageScaleSpinner.setBounds(112, 73, 51, 22);
		imageScaleSpinner.setDigits(1);
		imageScaleSpinner.setMinimum(10);
		imageScaleSpinner.setMaximum(40);
		imageScaleSpinner.setIncrement(1);
		imageScaleSpinner.setSelection((int)(params.imageScale * 10)); 
		imageScaleSpinner.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
		        int selection = imageScaleSpinner.getSelection();
		        int digits = imageScaleSpinner.getDigits();
		        params.imageScale = (selection / Math.pow(10, digits)); 
		        updateGUI(false);
			}
		});
		
		lblJpegQuality = new Label(composite, SWT.NONE);
		lblJpegQuality.setBounds(10, 51, 81, 14);
		lblJpegQuality.setText("JPEG quality");
		
		Label lblImageScale = new Label(composite, SWT.NONE);
		lblImageScale.setBounds(10, 75, 81, 14);
		lblImageScale.setText("Image scale");
		
		Scale hiedgeSlider = new Scale(composite, SWT.NONE);
		hiedgeSlider.setBounds(10, 112, 128, 20);
		hiedgeSlider.setMaximum(main.hiedgeMax);
		hiedgeSlider.setSelection(params.hiedge);
		hiedgeSlider.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				params.hiedge = ((Scale)e.widget).getSelection();
				updateGUI(false);
			}
		});
		
		
		Scale loedgeSlider = new Scale(composite, SWT.NONE);
		loedgeSlider.setBounds(10, 136, 128, 20);
		loedgeSlider.setMaximum(main.loedgeMax);
		loedgeSlider.setSelection(params.loedge);
		loedgeSlider.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				params.loedge = ((Scale)e.widget).getSelection();
				updateGUI(false);
			}
		});
		
		whiteEdgeLabel = new Label(composite, SWT.NONE);
		whiteEdgeLabel.setBounds(150, 114, 81, 14);
		
		blackEdgeLabel = new Label(composite, SWT.NONE);
		blackEdgeLabel.setBounds(150, 138, 81, 14);
		
		Scale filterScale = new Scale(composite, SWT.NONE);
		filterScale.setBounds(10, 160, 128, 20);
		filterScale.setMaximum(main.filterMax);
		filterScale.setSelection(params.filter);
		filterScale.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				params.filter = ((Scale)e.widget).getSelection();
				updateGUI(false);
			}
		});
		filterScale.setEnabled(false);
		
		lblMedianFilter = new Label(composite, SWT.NONE);
		lblMedianFilter.setBounds(150, 162, 96, 14);
		lblMedianFilter.setText("Filter (0)");
		
		imageSize = new Label(composite, SWT.NONE);
		imageSize.setBounds(10, 204, 230, 38);
		scrolledComposite.setLayoutData(fd_scrolledComposite);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		FontData[] fD = imageSize.getFont().getFontData();
		if ( main.win ) {
			fD[0].setHeight(16);
		} else {
			fD[0].setHeight(20);
		}
		imageSize.setFont( new Font(shlJpegQuality.getDisplay(),fD[0]));

		numberOfPages = new Label(composite, SWT.NONE);
		numberOfPages.setBounds(10, 244, 230, 18);
		scrolledComposite.setLayoutData(fd_scrolledComposite);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		fD = numberOfPages.getFont().getFontData();
		if ( main.win ) {
			fD[0].setHeight(12);
		} else {
			fD[0].setHeight(14);
		}
		numberOfPages.setFont( new Font(shlJpegQuality.getDisplay(),fD[0]));
		
		bookSize = new Label(composite, SWT.NONE);
		bookSize.setBounds(10, 267, 230, 22);
		scrolledComposite.setLayoutData(fd_scrolledComposite);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		fD = bookSize.getFont().getFontData();
		if ( main.win ) {
			fD[0].setHeight(12);
		} else {
			fD[0].setHeight(14);
		}
		bookSize.setFont( new Font(shlJpegQuality.getDisplay(),fD[0]));
		
		Label lblImageType = new Label(composite, SWT.NONE);
		lblImageType.setBounds(10, 10, 70, 14);
		lblImageType.setText("Image type");
		
		Button btnPreviewAsPdf = new Button(composite, SWT.NONE);
		btnPreviewAsPdf.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				try {
					com.itextpdf.text.Rectangle format = new com.itextpdf.text.Rectangle(main.deviceWidth, main.deviceHeight);
					com.itextpdf.text.Document document = new com.itextpdf.text.Document(format, 0, 0, 0, 0);

					File resultPdf = File.createTempFile("djvu", ".pdf");
					resultPdf.deleteOnExit();
					
					PdfWriter pdfwriter = PdfWriter.getInstance(document, new FileOutputStream(resultPdf));
					pdfwriter.setCompressionLevel(0);
					pdfwriter.setViewerPreferences(PdfWriter.PageLayoutSinglePage);
					document.open();
					
					PdfDictionary dic = pdfwriter.getInfo();
					dic.put(PdfName.CREATOR, new PdfString("DJVU to PDF eBook converter. http://pd4ml.com/djvu.htm", PdfObject.TEXT_UNICODE));
					dic.put(PdfName.TITLE, new PdfString(main.book.getTitle(), PdfObject.TEXT_UNICODE));
					dic.put(PdfName.AUTHOR, new PdfString(main.book.getAuthor(), PdfObject.TEXT_UNICODE));

					com.itextpdf.text.Image img = com.itextpdf.text.Image.getInstance(imageFile.getAbsolutePath());
			        img.setAbsolutePosition(0,0);
			        img.scaleAbsolute(format.getWidth(), format.getHeight());
				    pdfwriter.getDirectContent().addImage(img, true);
					
				    document.close();
					org.eclipse.swt.program.Program.launch("file:" + resultPdf.getAbsolutePath());				
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				
			}
		});
		btnPreviewAsPdf.setBounds(10, 310, 128, 30);
		btnPreviewAsPdf.setText("Preview as PDF");
		
		Label label = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setBounds(0, 37, 250, 2);
		
		Label label_1 = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_1.setBounds(0, 104, 250, 2);
		
		Label label_2 = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_2.setBounds(0, 189, 250, 2);
		
		Label label_3 = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_3.setBounds(0, 300, 250, 2);

		Button applyButton = new Button(shlJpegQuality, SWT.NONE);
		applyButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				main.dialogCancelled = false;
				shlJpegQuality.dispose();
			}
		});
		applyButton.setBackground(shlJpegQuality.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		applyButton.setText("Apply");
		FormData fd_button = new FormData();
		fd_button.bottom = new FormAttachment(100, -10);
		fd_button.right = new FormAttachment(100, -10);
		applyButton.setLayoutData(fd_button);
		
		Button cancelButton = new Button(shlJpegQuality, SWT.NONE);
		cancelButton.setBackground(shlJpegQuality.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		cancelButton.setText("Cancel");
		fd_button = new FormData();
		fd_button.bottom = new FormAttachment(100, -10);
		fd_button.right = new FormAttachment(applyButton, -6);
		cancelButton.setLayoutData(fd_button);
		cancelButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				main.dialogCancelled = true;
				shlJpegQuality.dispose();
			}
		});
		
		updateGUI(false);
	}
	
	public void updateGUI( boolean onlyImageTypeChanged ) {
		whiteEdgeLabel.setText("White (" + params.hiedge + ")");
		blackEdgeLabel.setText("Black (" + params.loedge + ")");
		lblMedianFilter.setText("Filter (" + params.filter + ")");
		lblMedianFilter.setForeground(shlJpegQuality.getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
		
		String imgType = "jpeg";
		String imgExt = ".jpg";
		
		if ( params.imageType > 1 ) {
			imgType = "png";
			imgExt = ".png";
			jpegQualitySpinner.setEnabled(false);
			lblJpegQuality.setForeground(shlJpegQuality.getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
		} else {
			jpegQualitySpinner.setEnabled(true);
			lblJpegQuality.setForeground(shlJpegQuality.getDisplay().getSystemColor(SWT.COLOR_BLACK));
		}
		
		try {
			if ( page == null ) {
				page = main.book.getPage(main.currentPage, params.split, params.imageScale, shlJpegQuality.getDisplay(), false);
			}
			
			if (!onlyImageTypeChanged) {
				bimg = ConversionInProgressDialog.prepareImage(main.currentPage, params, page, main);
			}

			if ( imageFile != null && imageFile.exists() ) {
				imageFile.delete();
			}
			imageFile = File.createTempFile("spool", imgExt );
			imageFile.deleteOnExit();

			Iterator iter = ImageIO.getImageWritersByFormatName(imgType);
			ImageWriter writer;
			ImageWriteParam iwp;
			
			switch(params.imageType) {
			case 2:
			case 3:
				writer = (ImageWriter)iter.next();
				iwp = writer.getDefaultWriteParam();
				break;
			default:
				iter = ImageIO.getImageWritersByFormatName(imgType);
				writer = (ImageWriter)iter.next();
				iwp = writer.getDefaultWriteParam();
				iwp.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
				iwp.setCompressionQuality((float)params.jpegQual);
			}
			
			if ( params.split ) {
				ConversionInProgressDialog.writeFirstImageOfPair(params, imageFile, bimg, writer, iwp, main);
			} else {
				ConversionInProgressDialog.writeSingleImage(params, imageFile, bimg, writer, iwp, main);
			}

			Image image = new Image(shlJpegQuality.getDisplay(), imageFile.getPath());
			scrolledComposite.setMinSize(image.getImageData().width, image.getImageData().height);
			displayTarget.setImage(image);

			jpegSize = imageFile.length();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		imageSize.setText("Image size: " + Util.formatNumber(jpegSize));
		int numberOfImages = main.getExpectedNumberOfPages(0, main.book.getTotalPages()); 
		numberOfPages.setText("Number of images in PDF: " + numberOfImages);
		int bsz = (int)(numberOfImages * jpegSize);
		bookSize.setText("Average eBook size: " + Util.formatNumber(bsz));
	}
}
