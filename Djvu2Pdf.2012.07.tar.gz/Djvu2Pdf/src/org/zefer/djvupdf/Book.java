package org.zefer.djvupdf;

import java.awt.Image;
import java.io.IOException;

import org.eclipse.swt.widgets.Display;

public abstract class Book {

	public boolean doublePage;
	protected int targetWidth; 
	protected int targetHeight; 

	public Book() {
	}

	public abstract int getTotalPages();

	public abstract BookPage getPage( int pageNumber, boolean split, double imageScale, Display display, boolean background ) throws IOException;

	public void setDoublePage(boolean doublePage) {
		this.doublePage = doublePage;
	}
	
	public void setTargetDimensions(int width, int height) {
		this.targetWidth = width;
		this.targetHeight = height;
	}
	
	public String getTitle() {
		return "";
	}

	public String getAuthor() {
		return "";
	}
	
	public class BookPage {
		public int width;
		public int height;
		public int[] data; 
		public boolean split;
	}
}
