package org.zefer.djvupdf;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.events.ShellListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.zefer.djvupdf.Book.BookPage;
import org.zefer.djvupdf.deskew.Deskewer;
import org.zefer.djvupdf.filter.TextEdgesFilter;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class DjvuConverter {

	private static final String CONVERTER_PROPERTIES = "converter.properties";

	protected Shell shell;

	private Scale topCut;
	private Scale bottomCut;
	private Scale leftCut;
	private Scale rightCut;
	private Text cutsStatusLabel;

	private String bookPropertiesName;
	
	private int marginMax = 250;
	private Text formatHeight;
	private Text formatWidth;
	private Combo formats;
	private Label lblWhite;
	private Label lblBlack;
	private Text currentPageLabel;
	private Button prevBut;
	private Button nextBut;
	private Button generateButton;
	private Button btnSplitAndRotate;
	private Button btnConstrainProportions;
	private Button btnFilterEdges;
	private Button btnDeskew;
	private Button doublePageCheckbox;
	private Button btnAdjustJpeg;
	private Label lblCropMargins;
	
	private Scale hiedgeSlider;
	private Scale loedgeSlider;
	
	private Label three;
	private Label four;
	private Label five;
	
	private Button overrideCurrentPageSettings;
	
	private HashMap individualPageSettings = new HashMap();
	private HashSet deletedPages = new HashSet();

	// application window bounds
	private int left = 0;
	private int top = 0;
    private int width = -1;
	private int height = -1;

	public ConversionParameters params = new ConversionParameters();
	public ConversionParameters documentParams = params;
	
	public boolean dialogCancelled;

	public boolean doublePageScan;
	
	int hiedgeMax = 180;
	int loedgeMax = 180;
	int filterMax = 32;
	
	public int deviceHeight = -1;
	public int deviceWidth = -1;
	
	private String recentFolder;
	private String recentDirectory;
	public String recentSaveDirectory;
	int currentPage = 0;
	int visitedPage = 0;
	
	private int recentFormatWidth = 480;
	private int recentFormatHeight = 640;
	
	private ScrolledComposite documentPane;
	private Label displayTarget;
	
	private boolean readPageAgain = true;
	private boolean scalePageAgain = true;
	
	HashMap angles;

	private int[] currentPagePixels;
	private int[] scaledPagePixels;
	private int currentPageWidth = 0;
	private int currentPageHeight = 0;
	
	public String activeDocument;
	
	public Book book;

	private boolean doNotUpdate;
	
	public static boolean win;
	private Button deletePageButton;
	
	private boolean openFolder = false;
	private boolean saveRange = false;
	Button btnOpenDjvu;
	private Button btnAutosaveSettings;

	private Composite controlsPane;
	
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		
		win = File.separatorChar == '\\';
		
		try {
			DjvuConverter window = new DjvuConverter();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		loadState();
		createContents();
		initGUI();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	public ConversionParameters getPageParameters(int pageNumber) {

		if (deletedPages.contains("" + pageNumber)) {
			return null;
		}
		
		ConversionParameters pp = (ConversionParameters)individualPageSettings.get("" + pageNumber);
		if ( pp == null ) {
			pp = documentParams;
		}
		
		return pp;
	}

	private void initGUI() {
		for ( int i = 0; i < PaperFormat.namedFormats.length; i++ ) {
			formats.add(PaperFormat.namedFormats[i].name);
		}
		updateGUI();
	}

	private void updateGUI() {
		
		if ( doNotUpdate ) {
			return;
		}
		
		if( !openFolder ) {
			btnOpenDjvu.setText("Open DJVU...");
		} else {
			btnOpenDjvu.setText("Open folder...");
		}
		
		try {
			int save = deviceWidth;
			deviceWidth = Integer.parseInt( formatWidth.getText().replaceAll("px", "") );
			if ( deviceWidth < 50 ) {
				deviceWidth = save;
			}
		} catch (NumberFormatException e) {
		} 
		
		try {
			int save = deviceHeight;
			deviceHeight = Integer.parseInt( formatHeight.getText().replaceAll("px", "") );
			if ( deviceHeight < 50 ) {
				deviceHeight = save;
			}
		} catch (NumberFormatException e) {
		}
		
		formatWidth.setText( "" + deviceWidth + "px" );
		formatHeight.setText( "" + deviceHeight + "px" );
		
		if ( book != null ) {
			book.setTargetDimensions(deviceWidth, deviceHeight);
		}
		
		lblWhite.setText("White (" + params.hiedge + ")");
		lblBlack.setText("Black (" + params.loedge + ")");

		if ( params.hiedge != hiedgeSlider.getSelection() ) {
			hiedgeSlider.setSelection(params.hiedge);
		}
		
		if ( params.loedge != loedgeSlider.getSelection() ) {
			loedgeSlider.setSelection(params.loedge);
		}
		
		PaperFormat f = PaperFormat.getFormat(deviceWidth, deviceHeight);
		String n = "Custom";
		if ( f != null ) {
			n = f.name;
		}
		String[] items = formats.getItems();
		for ( int i = 0; i < items.length; i++ ) {
			if ( n.equalsIgnoreCase(items[i]) ) {
				formats.select(i);
				break;
			}
		}

		if ( currentPage == 0 ) {
			prevBut.setEnabled(false);
		} else {
			prevBut.setEnabled(true);
		}

		int totalPages = 0;
		if ( book != null ) {
			totalPages = book.getTotalPages();
		}
		
		if ( totalPages == 0 || currentPage == totalPages - 1 ) {
			nextBut.setEnabled(false);
		} else {
			nextBut.setEnabled(true);
		}

		if ( totalPages == 0 ) {
			currentPageLabel.setText("0 of 0");
		} else {
			currentPageLabel.setText((currentPage + 1) + " of " + totalPages);
		}
		
		if ( params.getLeftMargin() != leftCut.getSelection() ) {
			leftCut.setSelection(params.getLeftMargin());
		}

		if ( params.getRightMargin() != rightCut.getSelection() ) {
			rightCut.setSelection(params.getRightMargin());
		}

		if ( params.getTopMargin() != topCut.getSelection() ) {
			topCut.setSelection(params.getTopMargin());
		}

		if ( params.getBottomMargin() != bottomCut.getSelection() ) {
			bottomCut.setSelection(params.getBottomMargin());
		}

		String pattern = "" + params.getLeftMargin() + ", " + params.getTopMargin() + ", " + 
				params.getRightMargin() + ", " + params.getBottomMargin();
		if ( !pattern.equals(cutsStatusLabel.getText()) ) {
			cutsStatusLabel.setText( pattern );
		}

		if ( params.split != btnSplitAndRotate.getSelection() ) {
			btnSplitAndRotate.setSelection(params.split);
		}
		
		if ( params.proportional != btnConstrainProportions.getSelection() ) {
			btnConstrainProportions.setSelection(params.proportional);
		}
		
		if ( params.autocrop != btnDeskew.getSelection() ) {
			btnDeskew.setSelection(params.autocrop);
			if (params.autocrop) {
				btnConstrainProportions.setEnabled(true);
			} else {
				btnConstrainProportions.setEnabled(false);
			}
		}
		
		btnFilterEdges.setSelection(params.edgeFilter);
		
		if ( doublePageScan != doublePageCheckbox.getSelection() ) {
			doublePageCheckbox.setSelection(doublePageScan);
		}
		
		three.setText("3.");
		four.setText("4.");
		five.setText("5.");

		String[] difs = params.differs(documentParams);
		if ( difs != null ) {
			if ( difs != null ) {
				for ( int i = 0; i < difs.length; i++ ) {
					if ( "3".equals(difs[i]) ) {
						three.setText("*3.");
					}
					if ( "4".equals(difs[i]) ) {
						four.setText("*4.");
					}
					if ( "5".equals(difs[i]) ) {
						five.setText("*5.");
					}
				}
			}
		}
		
		setControlsVisibility();
		
		drawCurrentPage();
	}

	private void setControlsVisibility() {

//		if ( book == null ) {
//			return;
//		}
		
		boolean deleted = deletedPages.contains("" + currentPage);
		boolean overriden = individualPageSettings.get("" + currentPage) != null;

		if ( deleted || book == null ) {
			if ( book != null ) {
				deletePageButton.setSelection(true);
				deletePageButton.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_RED));
			}
			doublePageCheckbox.setEnabled(false);
			formats.setEnabled(false);
			formatHeight.setEnabled(false);
			formatWidth.setEnabled(false);
			overrideCurrentPageSettings.setEnabled(false);

			cutsStatusLabel.setEnabled(false);
			leftCut.setEnabled(false);
			rightCut.setEnabled(false);
			topCut.setEnabled(false);
			bottomCut.setEnabled(false);
			lblCropMargins.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));

			hiedgeSlider.setEnabled(false);
			loedgeSlider.setEnabled(false);
			lblWhite.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
			lblBlack.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
			
			btnSplitAndRotate.setEnabled(false);
			btnDeskew.setEnabled(false);
			btnFilterEdges.setEnabled(false);
			btnConstrainProportions.setEnabled(false);
			btnConstrainProportions.setSelection(false);
			btnAdjustJpeg.setEnabled(false);
		} else {
			deletePageButton.setSelection(false);
			deletePageButton.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_BLACK));
			
			overrideCurrentPageSettings.setEnabled(true);
			
			cutsStatusLabel.setEnabled(true);
			leftCut.setEnabled(true);
			rightCut.setEnabled(true);
			topCut.setEnabled(true);
			bottomCut.setEnabled(true);
			lblCropMargins.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_BLACK));

			hiedgeSlider.setEnabled(true);
			loedgeSlider.setEnabled(true);
			lblWhite.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_BLACK));
			lblBlack.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_BLACK));
			
			btnSplitAndRotate.setEnabled(true);
			btnDeskew.setEnabled(true);
			btnFilterEdges.setEnabled(true);
			if ( params.autocrop ) {
				btnConstrainProportions.setEnabled(true);
				btnConstrainProportions.setSelection(params.proportional);
			} else {
				btnConstrainProportions.setEnabled(false);
				btnConstrainProportions.setSelection(false);
			}
			btnAdjustJpeg.setEnabled(true);
			
			if ( overriden ) {
				overrideCurrentPageSettings.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_RED));
				doublePageCheckbox.setEnabled(false);
				formats.setEnabled(false);
				formatHeight.setEnabled(false);
				formatWidth.setEnabled(false);
			} else {
				overrideCurrentPageSettings.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_BLACK));
				doublePageCheckbox.setEnabled(true);
				formats.setEnabled(true);
				formatHeight.setEnabled(true);
				formatWidth.setEnabled(true);
			}
		}
	}

	protected void drawCurrentPage() {

		if ( btnSplitAndRotate.getSelection() ) {
			documentPane.setMinSize(deviceHeight, deviceWidth * 2 + 30);
		} else {
			documentPane.setMinSize(deviceWidth, deviceHeight);
		}
		
		if ( book == null ) {
			return;
		}

		long start = System.currentTimeMillis();
//	    System.out.println( "------------------------------------------" );
		
		try {
			if ( readPageAgain ) {
				
				BookPage page = book.getPage(currentPage, params.split, params.imageScale, shell.getDisplay(), false);

//			    System.out.println( "read page duration: " + (System.currentTimeMillis() - start) );

				currentPageWidth = page.width;
				currentPageHeight = page.height;
				currentPagePixels = Arrays.copyOf(page.data, page.data.length);

				if( params.edgeFilter ) {
					TextEdgesFilter.filterText( currentPagePixels, currentPageWidth, currentPageHeight, 40, 130, .1f, .8f );
				}
				
				readPageAgain = false;
				scalePageAgain = true;

//			    System.out.println( "page read: " + (System.currentTimeMillis() - start) );
			
			}
			
			BufferedImage resultingImage;
			
			if ( btnSplitAndRotate.getSelection() ) {

				if ( scalePageAgain ) {

					if ( params.autocrop  ) {
						
						double angle = 0;
						Double agl = (Double)angles.get("" + currentPage);
						if ( agl == null ) {
							angle = Deskewer.getAngle(currentPagePixels, currentPageWidth, currentPageHeight);
//						    System.out.println( "width: " + currentPageWidth + ", height: " + currentPageHeight );
//						    System.out.println( "angle: " + angle );
						    if ( angle < .01 && angle > -.01 ) {
						    	angle = 0;
						    }
						    
						    angles.put("" + currentPage, new Double(angle));
						} else {
							angle = agl.doubleValue();
						}

						BufferedImage bimg = new BufferedImage(currentPageWidth, currentPageHeight, BufferedImage.TYPE_INT_RGB);
						try {
							bimg.setRGB(0, 0, currentPageWidth, currentPageHeight, currentPagePixels, 0, currentPageWidth);
						} catch (Exception e1) {
//							System.out.println( currentPageWidth + "," + currentPageHeight );
//							System.out.println( x + "," + y + "," + w + "," + h );
							e1.printStackTrace();
						}
					    
					    if ( angle != 0 ) {
					    	BufferedImage rotatedImage = new BufferedImage(currentPageWidth, currentPageHeight, BufferedImage.TYPE_INT_RGB);
					    	Graphics2D graphics2D = rotatedImage.createGraphics();
					    	AffineTransform xform = AffineTransform.getRotateInstance(angle);
					    	graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
					    	graphics2D.setColor(Color.white);
					    	graphics2D.fillRect(0, 0, currentPageWidth, currentPageHeight);
					    	graphics2D.drawImage(bimg, xform, null);
					    	graphics2D.dispose();
					    	bimg = rotatedImage;
					    }

						int[] straightImage = new int[currentPageWidth * currentPageHeight]; 
						PixelGrabber pg = new PixelGrabber(bimg, 0, 0, currentPageWidth, currentPageHeight, straightImage, 0, currentPageWidth);
						try {
							pg.grabPixels();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					    
					    AutoCrop ac = new AutoCrop(straightImage, currentPageWidth, currentPageHeight, 110, params);
					    ac.process();
						
						int x = ac.leftEdge;
						int y = ac.topEdge;
						int w = ac.rightEdge - x;
						int h = ac.bottomEdge - y;

						BufferedImage scaledImage = new BufferedImage(deviceHeight, deviceWidth * 2, BufferedImage.TYPE_INT_RGB);
						Graphics2D graphics2D = scaledImage.createGraphics();
						AffineTransform xform = AffineTransform.getScaleInstance((double) deviceHeight / w, (double) deviceWidth * 2 / h);
						graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
						graphics2D.translate((int)(((double)-deviceHeight/w)*x), (int)(((double)-deviceWidth*2/h)*y));
						graphics2D.drawImage(bimg, xform, null);
						graphics2D.dispose();
						
						scaledPagePixels = new int[deviceWidth * deviceHeight * 2]; 
						pg = new PixelGrabber(scaledImage, 0, 0, deviceHeight, deviceWidth * 2 + 20, scaledPagePixels, 0, deviceHeight);
						try {
							pg.grabPixels();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						
					} else {
						int x = leftCut.getSelection();
						int y = topCut.getSelection();
						int w = currentPageWidth - leftCut.getSelection() - rightCut.getSelection();
						int h = currentPageHeight - topCut.getSelection() - bottomCut.getSelection();
						
						BufferedImage bimg = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
						try {
							bimg.setRGB(0, 0, w, h, currentPagePixels, y * currentPageWidth + x, currentPageWidth);
						} catch (Exception e1) {
							System.out.println( currentPageWidth + "," + currentPageHeight );
							System.out.println( x + "," + y + "," + w + "," + h );
							e1.printStackTrace();
						}
						
						BufferedImage scaledImage = new BufferedImage(deviceHeight, deviceWidth * 2, BufferedImage.TYPE_INT_RGB);
						Graphics2D graphics2D = scaledImage.createGraphics();
						AffineTransform xform = AffineTransform.getScaleInstance((double) deviceHeight / w, (double) deviceWidth * 2 / h);
						graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
						graphics2D.drawImage(bimg, xform, null);
						graphics2D.dispose();
						
						scaledPagePixels = new int[deviceWidth * deviceHeight * 2]; 
						PixelGrabber pg = new PixelGrabber(scaledImage, 0, 0, deviceHeight, deviceWidth * 2 + 20, scaledPagePixels, 0, deviceHeight);
						try {
							pg.grabPixels();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					
					scalePageAgain = false;
				}
				
				int[] processed = Util.copyAndProcess(scaledPagePixels, deviceHeight, deviceWidth * 2, 255 - params.hiedge, params.loedge, params.edgeFilter);
				
				int split = Util.getSplitPosition(processed, deviceHeight, deviceWidth * 2, 20);

				resultingImage = new BufferedImage(deviceHeight, deviceWidth * 2 + 30, BufferedImage.TYPE_INT_RGB);
				resultingImage.setRGB(0, 0, deviceHeight, split, processed, 0, deviceHeight);

				resultingImage.setRGB(0, split + 30, deviceHeight, deviceWidth * 2 - split, processed, split * deviceHeight, deviceHeight);
				
				Graphics g = resultingImage.getGraphics();
				g.setColor(Color.LIGHT_GRAY);
				g.fillRect(0, split, deviceHeight, 30);
				
				if (deletedPages.contains("" + currentPage)) {
					g.setColor(Color.RED);
					g.drawRect(0, 0, deviceHeight-1, split-1);
					g.drawRect(0, split+30, deviceHeight-1, deviceWidth * 2 - split - 1);
				}
				g.dispose();

				
			} else {
				if ( scalePageAgain ) {
					if ( params.autocrop  ) {
						double angle = 0;
						Double agl = (Double)angles.get("" + currentPage);
						if ( agl == null ) {
							angle = Deskewer.getAngle(currentPagePixels, currentPageWidth, currentPageHeight);
//						    System.out.println( "width: " + currentPageWidth + ", height: " + currentPageHeight );
//						    System.out.println( "angle: " + angle );
						    if ( angle < .01 && angle > -.01 ) {
						    	angle = 0;
						    }

//						    System.out.println( "deskew duration: " + (System.currentTimeMillis() - start) );
						    
						    
						    angles.put("" + currentPage, new Double(angle));
						} else {
							angle = agl.doubleValue();
						}

						BufferedImage bimg = new BufferedImage(currentPageWidth, currentPageHeight, BufferedImage.TYPE_INT_RGB);
						try {
							bimg.setRGB(0, 0, currentPageWidth, currentPageHeight, currentPagePixels, 0, currentPageWidth);
						} catch (Exception e1) {
//							System.out.println( currentPageWidth + "," + currentPageHeight );
//							System.out.println( x + "," + y + "," + w + "," + h );
							e1.printStackTrace();
						}
					    
					    if ( angle != 0 ) {
					    	BufferedImage rotatedImage = new BufferedImage(currentPageWidth, currentPageHeight, BufferedImage.TYPE_INT_RGB);
					    	Graphics2D graphics2D = rotatedImage.createGraphics();
					    	AffineTransform xform = AffineTransform.getRotateInstance(angle);
					    	graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
					    	graphics2D.setColor(Color.white);
					    	graphics2D.fillRect(0, 0, currentPageWidth, currentPageHeight);
					    	graphics2D.drawImage(bimg, xform, null);
					    	graphics2D.dispose();
					    	bimg = rotatedImage;
					    }

						int[] straightImage = new int[currentPageWidth * currentPageHeight]; 
						PixelGrabber pg = new PixelGrabber(bimg, 0, 0, currentPageWidth, currentPageHeight, straightImage, 0, currentPageWidth);
						try {
							pg.grabPixels();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}

//					    System.out.println( "before crop: " + (System.currentTimeMillis() - start) );
						
					    AutoCrop ac = new AutoCrop(straightImage, currentPageWidth, currentPageHeight, 110, params);
					    ac.process();

//					    System.out.println( "crop duration: " + (System.currentTimeMillis() - start) );
					    
						int x = ac.leftEdge;
						int y = ac.topEdge;
						int w = ac.rightEdge - x;
						int h = ac.bottomEdge - y;

						BufferedImage scaledImage = new BufferedImage(deviceWidth, deviceHeight, BufferedImage.TYPE_INT_RGB);
						Graphics2D graphics2D = scaledImage.createGraphics();
						AffineTransform xform = AffineTransform.getScaleInstance((double) deviceWidth / w, (double) (deviceHeight)/ h);
						graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
						graphics2D.translate((int)(((double)-deviceWidth/w)*x), (int)(((double)-deviceHeight/h)*y));
						graphics2D.drawImage(bimg, xform, null);
						graphics2D.dispose();

//					    System.out.println( "scale duration: " + (System.currentTimeMillis() - start) );
						
						scaledPagePixels = new int[deviceWidth * deviceHeight]; 
						pg = new PixelGrabber(scaledImage, 0, 0, deviceWidth, deviceHeight, scaledPagePixels, 0, deviceWidth);
						try {
							pg.grabPixels();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}

//					    System.out.println( "grab duration: " + (System.currentTimeMillis() - start) );
						
						
					} else {
						int x = leftCut.getSelection();
						int y = topCut.getSelection();
						int w = currentPageWidth - leftCut.getSelection() - rightCut.getSelection();
						int h = currentPageHeight - topCut.getSelection() - bottomCut.getSelection();
						
						BufferedImage bimg = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
						try {
							bimg.setRGB(0, 0, w, h, currentPagePixels, y * currentPageWidth + x, currentPageWidth);
						} catch (Exception e1) {
							System.out.println( currentPageWidth + "," + currentPageHeight );
							System.out.println( x + "," + y + "," + w + "," + h );
							e1.printStackTrace();
						}
					    
						BufferedImage scaledImage = new BufferedImage(deviceWidth, deviceHeight, BufferedImage.TYPE_INT_RGB);
						Graphics2D graphics2D = scaledImage.createGraphics();
						AffineTransform xform = AffineTransform.getScaleInstance((double) deviceWidth / w, (double) (deviceHeight)/ h);
						graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
						graphics2D.drawImage(bimg, xform, null);
						graphics2D.dispose();
						
						scaledPagePixels = new int[deviceWidth * deviceHeight]; 
						PixelGrabber pg = new PixelGrabber(scaledImage, 0, 0, deviceWidth, deviceHeight, scaledPagePixels, 0, deviceWidth);
						try {
							pg.grabPixels();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					scalePageAgain = false;
				}

				int[] processed = Util.copyAndProcess(scaledPagePixels, deviceWidth, deviceHeight, 255 - params.hiedge, params.loedge, params.edgeFilter);
				
				resultingImage = new BufferedImage(deviceWidth, deviceHeight, BufferedImage.TYPE_INT_RGB);
				resultingImage.setRGB(0, 0, deviceWidth, deviceHeight, processed, 0, deviceWidth);

				if (deletedPages.contains("" + currentPage)) {
					Graphics g = resultingImage.getGraphics();
					g.setColor(Color.RED);
					g.drawRect(0, 0, deviceWidth-1, deviceHeight-1);
					g.dispose();
				}
			}

			ImageData id = Util.convertToSWT(resultingImage);
			if (id != null) {
				Image image = new Image(shell.getDisplay(), id);
				Image old = displayTarget.getImage();
				if ( old != null && !old.isDisposed() ) {
					old.dispose();
				}
				displayTarget.setImage(image);
			}

//		    System.out.println( "conversion duration: " + (System.currentTimeMillis() - start) );
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private void loadBookSettings( String path ) {
		Properties p = new Properties();
		try {
			p.load(new FileInputStream(path));
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
			e.printStackTrace();
		}

		String m = p.getProperty("page.max");
		String m2 = p.getProperty("page.-001.image.type");
		if ( m == null || m2 == null ) {
			System.out.println("invalid settings file " + path);
			return;
		}

		params = null;
		
		documentParams = new ConversionParameters();
		documentParams.load(p, -1);

		deletedPages.clear();
		
		int maxNr = Integer.parseInt(m);
		for ( int i = 0; i <= maxNr; i++ ) {
			String pageNumber = String.format("%04d", i);

			if ( "true".equalsIgnoreCase(p.getProperty("page." + pageNumber + ".skip")) ) {
				deletedPages.add(""+i);
				continue;
			}
			
			if ( p.getProperty("page." + pageNumber + ".image.type") == null ) {
				continue;
			}
			
			ConversionParameters pp = new ConversionParameters();
			pp.load(p, i);
			individualPageSettings.put(""+i, pp);
			
			if ( i == currentPage ) {
				params = pp;
			}
		}
		
		if ( params == null ) {
			params = documentParams;
		}
		
		readPageAgain = true;
		scalePageAgain = true;
		updateGUI();
	}
	
	private void pageChanged() {
		
		if ( btnAutosaveSettings.getSelection() ) {
			Properties p = new Properties() {
				  public synchronized Enumeration keys() {
					     Enumeration keysEnum = super.keys();
					     Vector keyList = new Vector();
					     while(keysEnum.hasMoreElements()){
					       keyList.add(keysEnum.nextElement());
					     }
					     Collections.sort(keyList);
					     return keyList.elements();
					  }
			};

			documentParams.save(p, -1);

			int maxNr = -1;
			
			Iterator ii = individualPageSettings.keySet().iterator();
			while ( ii.hasNext() ) {
				String key = (String)ii.next();
				ConversionParameters pp = (ConversionParameters)individualPageSettings.get(key);
				int nr = Integer.parseInt(key);
				maxNr = Math.max(maxNr, nr);
				pp.save(p, nr);
			}
			
			ii = deletedPages.iterator();
			while ( ii.hasNext() ) {
				String key = (String)ii.next();
				int nr = Integer.parseInt(key);
				maxNr = Math.max(maxNr, nr);
				String pageNumber = String.format("%04d", nr);
				p.put("page." + pageNumber + ".skip", "true");
			}

			p.put("page.max", ""+maxNr);
			
			try {
				p.store(new FileOutputStream(bookPropertiesName), null );
			} catch (FileNotFoundException e) {
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		visitedPage = currentPage;
		controlsPane.forceFocus();
	}
	
	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(715, 959);
		shell.setText("DJVU to PDF eBook converter");
		
		if ( width > 0 && height > 0 ) {
			shell.setBounds(left, top, width, height);
		}
		
		shell.setLayout(new FillLayout(SWT.HORIZONTAL));
		try {
			if ( win ) {
				Image icon = new Image(shell.getDisplay(), "djvu2pdf.ico");
				shell.setImage(icon);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		shell.addShellListener(new ShellListener() {
			public void shellClosed(ShellEvent arg0) {
				onExit();
			}
			public void shellDeactivated(ShellEvent arg0) {}
			public void shellDeiconified(ShellEvent arg0) {}
			public void shellIconified(ShellEvent arg0) {}
			public void shellActivated(ShellEvent event) {}
		});

		Composite main = new Composite(shell, SWT.NONE);
		main.setLayout(new FormLayout());
		main.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		controlsPane = new Composite(main, SWT.NONE);
		controlsPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				controlsPane.forceFocus();
			}
		});
		FormData fd_controlsPane = new FormData();
		fd_controlsPane.bottom = new FormAttachment(100, -40);
		fd_controlsPane.width = 250;
		fd_controlsPane.top = new FormAttachment(0, 10);
		fd_controlsPane.right = new FormAttachment(100, -10);
		controlsPane.setLayoutData(fd_controlsPane);
		controlsPane.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));

		controlsPane.addKeyListener(new KeyAdapter() {
			
			public void keyReleased(KeyEvent e) {
				if ( e.keyCode == SWT.SHIFT ) {
					openFolder = false;
					saveRange = false;
					btnOpenDjvu.setText("Open DJVU...");
					generateButton.setText("     Generate eBook     ");
				}
			}
			
			public void keyPressed(KeyEvent e) {

				if ( e.keyCode == SWT.SHIFT ) {
					openFolder = true;
					saveRange = true;
					btnOpenDjvu.setText("Open folder...");
					generateButton.setText("Generate page range");
				}
				
				if ( e.keyCode == SWT.ARROW_RIGHT && nextBut.getEnabled() ) {
					pageChanged();
					currentPage++;
					readPageAgain = true;
					scalePageAgain = true;
					updateGUI();
				}
				if ( e.keyCode == SWT.ARROW_LEFT && prevBut.getEnabled() ) {
					pageChanged();
					currentPage--;
					readPageAgain = true;
					scalePageAgain = true;
					updateGUI();
				}
				if ( e.keyCode == SWT.PAGE_DOWN && nextBut.getEnabled() ) {
					int totalPages = 0;
					if ( book != null ) {
						totalPages = book.getTotalPages();
					}
					
					pageChanged();
					currentPage = totalPages - 1;
					readPageAgain = true;
					scalePageAgain = true;
					updateGUI();
				}
				if ( e.keyCode == SWT.PAGE_UP && prevBut.getEnabled() ) {
					pageChanged();
					currentPage = 0;
					readPageAgain = true;
					scalePageAgain = true;
					updateGUI();
				}
				if ( e.keyCode == SWT.ALT ) {
					overrideCurrentPageSettings.setSelection(!overrideCurrentPageSettings.getSelection());
					
					if ( doNotUpdate ) {
						return;
					}

					if (overrideCurrentPageSettings.getSelection()) {
						params = params.clone();
						individualPageSettings.put("" + currentPage, params);
					} else {
						individualPageSettings.remove("" + currentPage);
						params = documentParams;
					}
					
					updateGUI();
				}
			}
		});
		controlsPane.forceFocus();
		
		documentPane = new ScrolledComposite(main, SWT.H_SCROLL | SWT.V_SCROLL);
		FormData fd_documentPane = new FormData();
		fd_documentPane.top = new FormAttachment(0, 10);
		fd_documentPane.left = new FormAttachment(0, 10);
		fd_documentPane.bottom = new FormAttachment(100, -40);
		fd_documentPane.right = new FormAttachment(controlsPane, -6);

		displayTarget = new Label(documentPane, SWT.CENTER);
		displayTarget.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_GRAY));
		documentPane.setContent(displayTarget);
		
		Font font = new Font(shell.getDisplay(), new FontData("Tahoma", 16, SWT.ITALIC | SWT.BOLD));

		{
			Label one = new Label(controlsPane, SWT.RIGHT);
			one.setBounds(0, 0, 30, 30);
			one.setText("1.");
			one.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_RED));
			one.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			one.setFont(font);	
			
			btnOpenDjvu = new Button(controlsPane, SWT.NONE);
			btnOpenDjvu.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));

			btnOpenDjvu.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					
					if ( openFolder ) {

						openFolder = false;
						
						DirectoryDialog dd = new DirectoryDialog(shell, SWT.OPEN | SWT.APPLICATION_MODAL);
				    	dd.setText("Choose a directory with scanned images to open");
						if (recentFolder != null) {
							dd.setFilterPath(recentFolder);
						}
						
						activeDocument = dd.open();

						recentFolder = dd.getFilterPath();
						if (activeDocument != null) {
							
							try {

								File f = new File(activeDocument);
								bookPropertiesName = f.getName();
								int ix = bookPropertiesName.indexOf('.');
								if (ix > 0) {
									bookPropertiesName = bookPropertiesName.substring(0, ix);
								}

								bookPropertiesName += ".bookprops";
								
								book = new ScannedBook(activeDocument, doublePageScan, deviceWidth, deviceHeight);
								int totalPages = book.getTotalPages();
								
								shell.setText("Scanned book to PDF eBook - " + activeDocument + " - " + totalPages + " pages");
								readPageAgain = true;
								scalePageAgain = true;
								angles = new HashMap();
								updateGUI();
								topCut.setEnabled(true);
								bottomCut.setEnabled(true);
								leftCut.setEnabled(true);
								rightCut.setEnabled(true);
								cutsStatusLabel.setEnabled(true);
								btnDeskew.setEnabled(true);
								btnAdjustJpeg.setEnabled(true);
								currentPageLabel.setEnabled(true);
								generateButton.setEnabled(true);
								deletePageButton.setEnabled(true);
								
								overrideCurrentPageSettings.setEnabled(true);
								
								deletedPages.clear();
								individualPageSettings.clear();

								controlsPane.forceFocus();
							} catch (Exception e1) {
								e1.printStackTrace();
							}
						}
						
					} else {
						FileDialog fd = new FileDialog(shell, SWT.OPEN | SWT.APPLICATION_MODAL);
				    	
				    	fd.setText("Choose DjVu file to open");
				    	fd.setFilterExtensions(new String[] {"*.djvu"});
				    	fd.setFilterNames(new String[] {"DjVu Document (*.djvu)"});
				    	fd.setFilterIndex(0);
				    	
						if (recentDirectory != null) {
							fd.setFilterPath(recentDirectory);
						}
						activeDocument = fd.open();
						recentDirectory = fd.getFilterPath();

						if (activeDocument != null) {
							
							try {
								
								book = new DjvuBook(activeDocument, doublePageScan, deviceWidth, deviceHeight);
								int totalPages = book.getTotalPages();
								
								shell.setText("DJVU to PDF eBook - " + activeDocument + " - " + totalPages + " pages");
								readPageAgain = true;
								scalePageAgain = true;
								angles = new HashMap();
								updateGUI();
								topCut.setEnabled(true);
								bottomCut.setEnabled(true);
								leftCut.setEnabled(true);
								rightCut.setEnabled(true);
								cutsStatusLabel.setEnabled(true);
								btnDeskew.setEnabled(true);
								btnAdjustJpeg.setEnabled(true);
								currentPageLabel.setEnabled(true);
								generateButton.setEnabled(true);
								deletePageButton.setEnabled(true);
								
								overrideCurrentPageSettings.setEnabled(true);
								
								deletedPages.clear();
								individualPageSettings.clear();

								bookPropertiesName = book.getTitle();
								if ( bookPropertiesName == null || "".equals(bookPropertiesName) ) {
									File f = new File(activeDocument);
									bookPropertiesName = f.getName();
									int ix = bookPropertiesName.indexOf('.');
									if (ix > 0) {
										bookPropertiesName = bookPropertiesName.substring(0, ix);
									}
								}

								bookPropertiesName += ".bookprops";
								
								controlsPane.forceFocus();
							} catch (Exception e1) {
								e1.printStackTrace();
							}
						}
					}

					updateGUI();
				}
			});
			btnOpenDjvu.setBounds(36, 5, 124, 20);
			btnOpenDjvu.setText("Open DJVU...");
			btnOpenDjvu.setToolTipText("Press SHIFT to open a folder with scanned images");
		}

		{
			Label two = new Label(controlsPane, SWT.RIGHT);
			two.setBounds(0, 33, 30, 30);
			two.setText("2.");
			two.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_RED));
			two.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			two.setFont(font);		
			
//			Label lblCooseFormat = new Label(controlsPane, SWT.NONE);
//			lblCooseFormat.setBounds(34, 50, 189, 18);
//			lblCooseFormat.setText("Define device screen resolution");
//			lblCooseFormat.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));

			formats = new Combo(controlsPane, SWT.NONE);
//			formats.setBounds(62, 138, 143, 22);
			formats.setBounds(80, 36, 143, 22);
			formats.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent e) {
					String selected = formats.getText();
					if ( !PaperFormat.isCustomFormat(selected) ) {
						PaperFormat f = PaperFormat.getFormat(selected);
						formatHeight.setText("" + f.height);
						formatWidth.setText("" + f.width);
					}
					readPageAgain = true;
					scalePageAgain = true;
					updateGUI();
				}
			});
			
			Label lblFormat = new Label(controlsPane, SWT.NONE);
			lblFormat.setToolTipText("You may add more devices in " + CONVERTER_PROPERTIES);
//			lblFormat.setBounds(6, 142, 80, 22);
			lblFormat.setBounds(34, 38, 80, 22);
			lblFormat.setText("Device:");
			lblFormat.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		}

		{
			Composite composite = new Composite(controlsPane, SWT.NONE);
			composite.setBounds(31, 55, 210, 130);
			composite.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));

			try {
				Image image = new Image(composite.getDisplay(),
						"./resources/format.gif");
				Label label = new Label(composite, SWT.NONE);
				label.setSize(111, 131);
				label.setImage(image);
			} catch (Exception e) {
				e.printStackTrace();
			}
			{
				formatHeight = new Text(composite, SWT.NONE);
				formatHeight.addKeyListener(new KeyAdapter() {
					@Override
					public void keyReleased(KeyEvent e) {
						if ( e.character == 13 ) {
							controlsPane.forceFocus();
						}
					}
				});
				formatHeight.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_BLUE));
				formatHeight.setBounds(114, 25, 68, 18);
				formatHeight.addFocusListener(new FocusAdapter() {
					@Override
					public void focusLost(FocusEvent e) {
						readPageAgain = true;
						updateGUI();
					}
				});
				formatHeight.setText("" + recentFormatHeight);
				formatHeight.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			}

			{
				formatWidth = new Text(composite, SWT.NONE);
				formatWidth.setBounds(114, 110, 68, 18);
				formatWidth.addKeyListener(new KeyAdapter() {
					@Override
					public void keyReleased(KeyEvent e) {
						if ( e.character == 13 ) {
							controlsPane.forceFocus();
						}
					}
				});
				formatWidth.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_BLUE));
				formatWidth.addFocusListener(new FocusAdapter() {
					@Override
					public void focusLost(FocusEvent e) {
						readPageAgain = true;
						updateGUI();
					}
				});
				formatWidth.setText("" + recentFormatWidth);
				formatWidth.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			}
		}

		{
			three = new Label(controlsPane, SWT.RIGHT);
			three.setBounds(0, 186, 30, 30);
			three.setText("3.");
			three.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_RED));
			three.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			three.setFont(font);		

			Label lblPageLayout = new Label(controlsPane, SWT.NONE);
			lblPageLayout.setBounds(34, 191, 72, 14);
			lblPageLayout.setText("Page layout");
			lblPageLayout.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		} 
		
		{
			doublePageCheckbox = new Button(controlsPane, SWT.CHECK);
			doublePageCheckbox.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					doublePageScan = doublePageCheckbox.getSelection();
					if ( book != null ) {
						book.setDoublePage(doublePageScan);
					}

					pageChanged();
					if ( doublePageScan ) {
						currentPage *= 2;
					} else {
						currentPage /= 2;
					}
					
					if ( deletedPages.size() > 0 ) {
						HashSet newOne = new HashSet();
						Object oo[] = deletedPages.toArray();
						if ( doublePageScan ) {
							for ( int i = 0; i < oo.length; i++) {
								String s = (String)oo[i];
								int ix = Integer.parseInt(s);
								newOne.add("" + (ix*2));
								newOne.add("" + (ix*2+1));
							}
						} else {
							for ( int i = 0; i < oo.length; i++) {
								String s = (String)oo[i];
								int ix = Integer.parseInt(s);
								if ( (ix % 2 == 0) && deletedPages.contains("" + (ix+1)) ) {
									newOne.add("" + (ix/2));
								}
							}
						}
						deletedPages = newOne;
					}

					if ( individualPageSettings.size() > 0 ) {
						HashMap newOne = new HashMap();
						Object oo[] = individualPageSettings.keySet().toArray();
						if ( doublePageScan ) {
							for ( int i = 0; i < oo.length; i++) {
								String s = (String)oo[i];
								int ix = Integer.parseInt(s);
								Object o = individualPageSettings.get(s);
								newOne.put("" + (ix*2), o);
								newOne.put("" + (ix*2+1), o);
							}
						} else {
							for ( int i = 0; i < oo.length; i++) {
								String s = (String)oo[i];
								int ix = Integer.parseInt(s);
								Object o = individualPageSettings.get(s);
								if ( (ix % 2 == 0) && individualPageSettings.get("" + (ix+1)) != null ) {
									newOne.put("" + (ix/2), o);
								}
							}
						}
						individualPageSettings = newOne;
					}
					
					readPageAgain = true;
					scalePageAgain = true;
					updateGUI();
				}
			});

			doublePageCheckbox.setBounds(33, 213, 175, 18);
			doublePageCheckbox.setText("Double-page scan");
			doublePageCheckbox.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));

			btnSplitAndRotate = new Button(controlsPane, SWT.CHECK);
			btnSplitAndRotate.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					params.split = btnSplitAndRotate.getSelection();
					scalePageAgain = true;
					angles = new HashMap();
					updateGUI();
				}
			});
			btnSplitAndRotate.setBounds(33, 232, 125, 18);
			btnSplitAndRotate.setText("Split and rotate");
			btnSplitAndRotate.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		}

		{
			four = new Label(controlsPane, SWT.RIGHT);
			four.setBounds(0, 259, 30, 30);
			four.setText("4.");
			four.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_RED));
			four.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			four.setFont(font);		
			
			Label lblCutMargins = new Label(controlsPane, SWT.NONE);
			lblCutMargins.setBounds(34, 264, 90, 18);
			lblCutMargins.setText("Page content");
			lblCutMargins.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		}

		{
			btnDeskew = new Button(controlsPane, SWT.CHECK);
			btnDeskew.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					params.autocrop = btnDeskew.getSelection();
					scalePageAgain = true;
					angles = new HashMap();

					btnConstrainProportions.setEnabled(btnDeskew.getSelection()); 
					
					doNotUpdate = true;
					leftCut.setSelection(params.getLeftMargin());
					topCut.setSelection(params.getTopMargin());
					rightCut.setSelection(params.getRightMargin());
					bottomCut.setSelection(params.getBottomMargin());			
					cutsStatusLabel.setText( "" + params.getLeftMargin() + ", " + params.getTopMargin() + ", " + 
							params.getRightMargin() + ", " + params.getBottomMargin() );
					doNotUpdate = false;

					if ( params.autocrop ) {
						lblCropMargins.setText("Add margins");
					} else {
						lblCropMargins.setText("Crop margins");
					}
					
					updateGUI();
				}
			});
			
			btnDeskew.setBounds(33, 284, 135, 18);
			btnDeskew.setText("Deskew and Autocrop");
			btnDeskew.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			btnDeskew.setEnabled(false);

			btnConstrainProportions = new Button(controlsPane, SWT.CHECK);
			btnConstrainProportions.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					params.proportional = btnConstrainProportions.getSelection();
					scalePageAgain = true;
					updateGUI();
				}
			});
			btnConstrainProportions.setBounds(173, 284, 175, 18);
			btnConstrainProportions.setText("Constrain");
			btnConstrainProportions.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			btnConstrainProportions.setEnabled(false);
			btnConstrainProportions.setSelection(true);

			btnFilterEdges = new Button(controlsPane, SWT.CHECK);
			btnFilterEdges.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					params.edgeFilter = btnFilterEdges.getSelection();
					readPageAgain = true;
					updateGUI();
				}
			});
			btnFilterEdges.setBounds(33, 303, 175, 18);
			btnFilterEdges.setText("Smart background filter");
			btnFilterEdges.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			btnFilterEdges.setEnabled(false);
			btnFilterEdges.setSelection(false);
		
		}

		{
			Composite composite = new Composite(controlsPane, SWT.NONE);
			composite.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			composite.setBounds(31, 323, 210, 154);
			
			{
				Image image = new Image(composite.getDisplay(), "resources/margins.gif");
				Label label = new Label(composite, SWT.NONE);
				label.setBounds(0, 2, 111, 131);
				label.setImage(image);
			}
			
			{
				topCut = new Scale(composite, SWT.NONE);
				topCut.setBounds(117, 2, 80, 20);
				topCut.setMaximum(marginMax);
				topCut.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						params.setTopMargin(topCut.getSelection());
						cutsStatusLabel.setText( "" + params.getLeftMargin() + ", " + params.getTopMargin() + ", " + 
								params.getRightMargin() + ", " + params.getBottomMargin() );
						scalePageAgain = true;
						updateGUI();
					}
				});
//				topCut.setEnabled(false);
				topCut.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			}
			
			{
				bottomCut = new Scale(composite, SWT.NONE);
				bottomCut.setBounds(117, 26, 80, 20);
				bottomCut.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						params.setBottomMargin(bottomCut.getSelection());
						cutsStatusLabel.setText( "" + params.getLeftMargin() + ", " + params.getTopMargin() + ", " + 
								params.getRightMargin() + ", " + params.getBottomMargin() );
						scalePageAgain = true;
						updateGUI();
					}
				});
				bottomCut.setMaximum(marginMax);
				bottomCut.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			}
			{
				lblCropMargins = new Label(composite, SWT.NONE);
				lblCropMargins.setBounds(116, 62, 79, 14);
				lblCropMargins.setText("Crop margins");
				lblCropMargins.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			}
			{
				rightCut = new Scale(composite, SWT.NONE);
				rightCut.setBounds(117, 95, 80, 20);
				rightCut.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						params.setRightMargin(rightCut.getSelection());
						cutsStatusLabel.setText( "" + params.getLeftMargin() + ", " + params.getTopMargin() + ", " + 
								params.getRightMargin() + ", " + params.getBottomMargin() );
						scalePageAgain = true;
						updateGUI();
					}
				});
				rightCut.setMaximum(marginMax);
				rightCut.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			}
			
			{
				leftCut = new Scale(composite, SWT.NONE);
				leftCut.setBounds(117, 118, 80, 20);
				leftCut.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						params.setLeftMargin(leftCut.getSelection());
						cutsStatusLabel.setText( "" + params.getLeftMargin() + ", " + params.getTopMargin() + ", " + 
								params.getRightMargin() + ", " + params.getBottomMargin() );
						scalePageAgain = true;
						updateGUI();
					}
				});
				leftCut.setMaximum(marginMax);
				leftCut.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			}
			
			{
				cutsStatusLabel = new Text(composite, SWT.NONE);
				cutsStatusLabel.setBounds(6, 136, 141, 20);
				cutsStatusLabel.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
				cutsStatusLabel.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_BLUE));
				
				cutsStatusLabel.addKeyListener(new KeyAdapter() {
					@Override
					public void keyReleased(KeyEvent e) {
						if ( e.character == 13 ) {
							controlsPane.forceFocus();
						}
					}
				});
				cutsStatusLabel.addFocusListener(new FocusAdapter() {
					@Override
					public void focusLost(FocusEvent e) {
						StringTokenizer st = new StringTokenizer(cutsStatusLabel.getText(), ",");
						if ( st.countTokens() == 4 ) {
							try {
								String leftStr = st.nextToken().trim();
								String topStr = st.nextToken().trim();
								String rightStr = st.nextToken().trim();
								String bottomStr = st.nextToken().trim();

								int left = Math.min(marginMax, Math.max(0, Integer.parseInt(leftStr)));
								int top = Math.min(marginMax, Math.max(0, Integer.parseInt(topStr)));
								int right = Math.min(marginMax, Math.max(0, Integer.parseInt(rightStr)));
								int bottom = Math.min(marginMax, Math.max(0, Integer.parseInt(bottomStr)));

								leftCut.setSelection(left);
								topCut.setSelection(top);
								rightCut.setSelection(right);
								bottomCut.setSelection(bottom);
								
								params.setLeftMargin(left);
								params.setRightMargin(right);
								params.setTopMargin(top);
								params.setBottomMargin(bottom);
								
								scalePageAgain = true;
								cutsStatusLabel.setText( "" + params.getLeftMargin() + ", " + params.getTopMargin() + ", " + 
										params.getRightMargin() + ", " + params.getBottomMargin() );

								updateGUI();
							} catch (Exception e1) {
							}
						}
					}
				});
				
			}
		}
		
		{
			five = new Label(controlsPane, SWT.RIGHT);
			five.setBounds(0, 482, 30, 30);
			five.setText("5.");
			five.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			five.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_RED));
			five.setFont(font);		
			
			Label lblThreshold = new Label(controlsPane, SWT.NONE);
			lblThreshold.setBounds(34, 488, 129, 18);
			lblThreshold.setText("Output");
			lblThreshold.setToolTipText("You may redefine the maximal values in " + CONVERTER_PROPERTIES);
			lblThreshold.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		}
		
		lblWhite = new Label(controlsPane, SWT.NONE);
		lblWhite.setBounds(157, 509, 72, 14);
		lblWhite.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		lblBlack = new Label(controlsPane, SWT.NONE);
		lblBlack.setBounds(157, 529, 72, 14);
		lblBlack.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		hiedgeSlider = new Scale(controlsPane, SWT.NONE);
		hiedgeSlider.setMaximum(hiedgeMax);
		hiedgeSlider.setSelection(params.hiedge);
		hiedgeSlider.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				params.hiedge = ((Scale)e.widget).getSelection();
				if ( params.autocrop ) {
					scalePageAgain = true; 
				}
				updateGUI();
			}
		});
		hiedgeSlider.setBounds(38, 508, 112, 20);
		hiedgeSlider.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		loedgeSlider = new Scale(controlsPane, SWT.NONE);
		loedgeSlider.setMaximum(loedgeMax);
		loedgeSlider.setSelection(params.loedge);
		loedgeSlider.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				params.loedge = ((Scale)e.widget).getSelection();
				updateGUI();
			}
		});
		loedgeSlider.setBounds(38, 527, 112, 20);
		loedgeSlider.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));

		documentPane.setLayoutData(fd_documentPane);
		documentPane.setExpandHorizontal(true);
		documentPane.setExpandVertical(true);
		documentPane.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		generateButton = new Button(main, SWT.NONE);
		generateButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				int from = 1;
				int to = book.getTotalPages();
				
				if ( saveRange ) {
					PageRangeDialog pr = new PageRangeDialog(shell, DjvuConverter.this, from, to);
					pr.open();
					from = pr.from;
					to = pr.to;
				}
				
				ConversionInProgressDialog cipd = new ConversionInProgressDialog(shell, DjvuConverter.this, from, to);
				cipd.open();
			}
		});
		FormData fd_generateButton = new FormData();
		fd_generateButton.top = new FormAttachment(controlsPane);
		generateButton.setLayoutData(fd_generateButton);
		generateButton.setText("     Generate eBook     ");
		generateButton.setEnabled(false);
		generateButton.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		Button btnQuit = new Button(main, SWT.NONE);
		btnQuit.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		btnQuit.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				onExit();
			}
		});
		fd_generateButton.right = new FormAttachment(btnQuit);
		FormData fd_btnQuit = new FormData();
		fd_btnQuit.top = new FormAttachment(controlsPane);
		
		btnAdjustJpeg = new Button(controlsPane, SWT.NONE);
		btnAdjustJpeg.addSelectionListener(new SelectionAdapter() {

			public void widgetSelected(SelectionEvent e) {
				ConversionParameters paramsSav = params.clone();
				boolean docWide = false;
				if ( individualPageSettings.get("" + currentPage) == null ) {
					docWide = true;
				}
				JpegPreviewer jp = new JpegPreviewer(shell, DjvuConverter.this, params);
				jp.open();
				
				if ( dialogCancelled ) {
					params = paramsSav;
					if ( docWide ) {
						documentParams = paramsSav;
					} else {
						individualPageSettings.put("" + currentPage, paramsSav);
					}
				} else {
					updateGUI();
				}
			}
		});
		
		if ( win ) {
			btnAdjustJpeg.setBounds(42, 555, 143, 20);
		} else {
			btnAdjustJpeg.setBounds(34, 553, 143, 20);
		}
		btnAdjustJpeg.setText("Adjust image quality");
		btnAdjustJpeg.setEnabled(false);
		
		overrideCurrentPageSettings = new Button(controlsPane, SWT.CHECK);
		overrideCurrentPageSettings.setToolTipText("press ALT to toggle");
		overrideCurrentPageSettings.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				if ( doNotUpdate ) {
					return;
				}

				if (overrideCurrentPageSettings.getSelection()) {
					params = params.clone();
					individualPageSettings.put("" + currentPage, params);
				} else {
					individualPageSettings.remove("" + currentPage);
					params = documentParams;
				}
				
				updateGUI();
			}
		});
		overrideCurrentPageSettings.setBounds(10, 587, 261, 18);
		overrideCurrentPageSettings.setText("Apply settings to the current page only");
		overrideCurrentPageSettings.setEnabled(false);
		overrideCurrentPageSettings.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));

		deletePageButton = new Button(controlsPane, SWT.CHECK);
		deletePageButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if ( doNotUpdate ) {
					return;
				}
				
				if (((Button)e.widget).getSelection()) {
					deletedPages.add("" + currentPage);
				} else {
					deletedPages.remove("" + currentPage);
				}
				
				updateGUI();
			}
		});
		deletePageButton.setBounds(10, 606, 101, 18);
		deletePageButton.setText("Skip the page");
		deletePageButton.setEnabled(false);
		deletePageButton.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));

		Link link = new Link(controlsPane, SWT.NONE);
		link.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				org.eclipse.swt.program.Program.launch("http://pd4ml.com/pxdjvu.htm");				
			}
		});
		link.setBounds(14, 670, 212, 14);
		link.setText("Home: <a href=\"http://pd4ml.com/pxdjvu.htm\">http://pd4ml.com/djvu.htm</a>");
		link.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		
		link = new Link(controlsPane, SWT.NONE);
		link.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				org.eclipse.swt.program.Program.launch("https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=3ATSAFQPQDZXW");				
			}
		});
		link.setBounds(14, 690, 212, 14);
		link.setText("Donate: <a href=\"https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=3ATSAFQPQDZXW\">PayPal</a>");
		link.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		
		Label label = new Label(controlsPane, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setBounds(0, 622, 250, 2);
		label.setVisible(false);
		
		Label label_1 = new Label(controlsPane, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_1.setBounds(0, 481, 250, 2);
		
		Label label_2 = new Label(controlsPane, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_2.setBounds(0, 258, 250, 2);
		
		Label label_3 = new Label(controlsPane, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_3.setBounds(0, 185, 250, 2);
		
		Label label_4 = new Label(controlsPane, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_4.setBounds(0, 30, 250, 2);
		
		Label label_6 = new Label(controlsPane, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_6.setBounds(0, 582, 250, 2);
		
		btnAutosaveSettings = new Button(controlsPane, SWT.CHECK);
		btnAutosaveSettings.setBounds(10, 639, 104, 16);
		btnAutosaveSettings.setText("Autosave settings");
		btnAutosaveSettings.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		
		Button btnLoadSettings = new Button(controlsPane, SWT.NONE);
		if ( win ) {
			btnLoadSettings.setBounds(120, 639, 120, 20);
		} else {
			btnLoadSettings.setBounds(120, 639, 120, 20);
		}
		btnLoadSettings.setText("Load book settings");
		btnLoadSettings.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog fd = new FileDialog(shell, SWT.OPEN | SWT.APPLICATION_MODAL);
		    	
		    	fd.setText("Choose saved book settings to open");
		    	fd.setFilterExtensions(new String[] {"*.bookprops"});
		    	fd.setFilterNames(new String[] {"Book settings (*.bookprops)"});
		    	fd.setFilterIndex(0);
				activeDocument = fd.open();

				if (activeDocument != null) {
					loadBookSettings(activeDocument);					
				}
			}
		});
		
		fd_btnQuit.right = new FormAttachment(100, -20);
		btnQuit.setLayoutData(fd_btnQuit);
		btnQuit.setText("Quit");
		
		{
			Composite navigationPane = new Composite(main, SWT.NONE);
			FormData fd_navigationPane = new FormData();
			fd_navigationPane.bottom = new FormAttachment(100, -15);
			fd_navigationPane.left = new FormAttachment(documentPane, 0, SWT.CENTER);
			
			fd_navigationPane.height = 22;
			fd_navigationPane.width = 132;
			navigationPane.setLayoutData(fd_navigationPane);
			navigationPane.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			
			prevBut = new Button(navigationPane, SWT.ARROW | SWT.LEFT);
			prevBut.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			
			prevBut.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					pageChanged();
					currentPage--;
					readPageAgain = true;
					scalePageAgain = true;

					getPageSpecificParamsIfDefined();
					
					updateGUI();
				}
			});
			prevBut.setBounds(1, 1, 20, 20);

			nextBut = new Button(navigationPane, SWT.ARROW | SWT.RIGHT);
			nextBut.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			
			nextBut.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) { 
					
					pageChanged();
					currentPage++;
					readPageAgain = true;
					scalePageAgain = true;

					getPageSpecificParamsIfDefined();
					
					updateGUI();
				}
			});
			nextBut.setBounds(111, 1, 20, 20);
			
			currentPageLabel = new Text(navigationPane, SWT.CENTER);
			currentPageLabel.setToolTipText("Enter page number");
			FontData[] fD = currentPageLabel.getFont().getFontData();
			if (win) {
				fD[0].setHeight(12);
			} else {
				fD[0].setHeight(14);
			}
			currentPageLabel.setFont( new Font(shell.getDisplay(),fD[0]));
			currentPageLabel.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WHITE));
			currentPageLabel.setForeground(shell.getDisplay().getSystemColor(SWT.COLOR_BLUE));
			currentPageLabel.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					if ( e.character == 13 ) {
						controlsPane.forceFocus();
						String text = currentPageLabel.getText();
						int start = -1;
						int end = -1;
						for ( int i = 0; i < text.length(); i++ ) {
							char c = text.charAt(i);
							if (Character.isDigit(c)) {
								if ( start < 0 ) {
									start = i;
								}
								continue;
							} else {
								if ( start >= 0 ) {
									end = i;
									break;
								}
								continue;
							}
						}
						if ( start >= 0 ) {
							int totalPages = 0;
							if ( book != null ) {
								totalPages = book.getTotalPages();
							}
							
							if ( end < 0 ) {
								end = text.length();
							}
							try {
								int page = Integer.parseInt(text.substring(start,end));
								page--;
								if ( page >= 0 && page < totalPages ) {
									pageChanged();
									currentPage = page;
								}
							} catch (NumberFormatException e1) {
							}
						}
						readPageAgain = true;
						scalePageAgain = true;

						getPageSpecificParamsIfDefined();
						
						updateGUI();
					}
				}
			});
			currentPageLabel.setBounds(21, 1, 90, 20);
			currentPageLabel.setEnabled(false);
		}
	}

	private void getPageSpecificParamsIfDefined() {

		doNotUpdate = true;
		three.setText("3.");
		four.setText("4.");
		five.setText("5.");
		
		ConversionParameters pp = (ConversionParameters)individualPageSettings.get("" + currentPage);
		if ( pp != null ) {

			params = pp;
			overrideCurrentPageSettings.setSelection(true);
			setControlsVisibility();
			
			String[] difs = params.differs(documentParams);
			if ( difs != null ) {
				for ( int i = 0; i < difs.length; i++ ) {
					if ( "3".equals(difs[i]) ) {
						three.setText("*3.");
					}
					if ( "4".equals(difs[i]) ) {
						four.setText("*4.");
					}
					if ( "5".equals(difs[i]) ) {
						five.setText("*5.");
					}
				}
			}
			
		} else {
			params = documentParams;
			overrideCurrentPageSettings.setSelection(false);
			setControlsVisibility();
		}
		
		doNotUpdate = false;
	}
	
	protected void onExit() {
		Properties p = new Properties() {
			  public synchronized Enumeration keys() {
				     Enumeration keysEnum = super.keys();
				     Vector keyList = new Vector();
				     while(keysEnum.hasMoreElements()){
				       keyList.add(keysEnum.nextElement());
				     }
				     Collections.sort(keyList);
				     return keyList.elements();
				  }
		};

		p.put("window.width", "" + shell.getBounds().width);
		p.put("window.height", "" + shell.getBounds().height);
		p.put("window.left", "" + shell.getBounds().x);
		p.put("window.top", "" + shell.getBounds().y);

		p.put("threshold.white", "" + documentParams.hiedge);
		p.put("threshold.black", "" + documentParams.loedge);
		p.put("threshold.white.max", "" + hiedgeMax);
		p.put("threshold.black.max", "" + loedgeMax);

		p.put("margin.cut.max", "" + marginMax);

		p.put("recent.format.width", formatWidth.getText());
		p.put("recent.format.height", formatHeight.getText());
		
		p.put("image.scale.factor", "" + documentParams.imageScale);
		p.put("image.jpeg.quality", "" + documentParams.jpegQual);
		p.put("image.apply.filter", "" + documentParams.filter);
		
		if ( recentDirectory != null ) {
			p.put("recent.directory", recentDirectory);
		}
		
		if ( recentFolder != null ) {
			p.put("recent.folder", recentFolder);
		}
		
		if ( recentSaveDirectory != null ) {
			p.put("recent.save.directory", recentSaveDirectory);
		}

		PaperFormat.saveProperties(p);
		
		try {
			p.store(new FileOutputStream(CONVERTER_PROPERTIES), null );
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
			e.printStackTrace();
		}

		pageChanged();
		
		System.exit(0);
	}

	private void loadState() {
		Properties p = new Properties();
		try {
			p.load(new FileInputStream(CONVERTER_PROPERTIES));
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
			e.printStackTrace();
		}

		PaperFormat.readProperties(p);
		
		left = Math.max(0, Integer.parseInt(p.getProperty("window.left", ""+left)));
		top = Math.max(0, Integer.parseInt(p.getProperty("window.top", ""+top)));
		width = Integer.parseInt(p.getProperty("window.width", "" + width));
		height = Integer.parseInt(p.getProperty("window.height", "" + height));

		recentFormatWidth = Integer.parseInt(p.getProperty("recent.format.width", "" + recentFormatWidth).replaceAll("px", ""));
		recentFormatHeight = Integer.parseInt(p.getProperty("recent.format.height", "" + recentFormatHeight).replaceAll("px", ""));
		
		params.hiedge = Integer.parseInt(p.getProperty("threshold.white", "" + params.hiedge));
		params.loedge = Integer.parseInt(p.getProperty("threshold.black", "" + params.loedge));
		hiedgeMax = Integer.parseInt(p.getProperty("threshold.white.max", "" + hiedgeMax));
		loedgeMax = Integer.parseInt(p.getProperty("threshold.black.max", "" + loedgeMax));

		marginMax = Integer.parseInt(p.getProperty("margin.cut.max", "" + marginMax));
		
		params.imageScale = Double.parseDouble(p.getProperty("image.scale.factor", "" + params.imageScale));
		params.jpegQual = Double.parseDouble(p.getProperty("image.jpeg.quality", "" + params.jpegQual));
		params.filter = Integer.parseInt(p.getProperty("image.apply.filter", "" + params.filter));
		
		recentSaveDirectory = p.getProperty("recent.save.directory");
		recentDirectory = p.getProperty("recent.directory");
		if ( "null".equalsIgnoreCase(recentDirectory) ) {
			recentDirectory = null;
		}
		recentFolder = p.getProperty("recent.folder");
		if ( "null".equalsIgnoreCase(recentFolder) ) {
			recentFolder = null;
		}
	}

	public int getExpectedNumberOfPages(int from, int to) {
		
		int pages = 0;
		
		for ( int i = from; i < to; i++ ) {
			ConversionParameters cp = getPageParameters(i);
			if (cp == null) {
				continue;
			}
			pages++;
			if ( cp.split ) {
				pages++;
			}
		}

		return pages;
	}
}
