package org.zefer.djvupdf;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class PageRangeDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text inputFrom;
	private Text inputTo;

	public int from;
	public int to;
	private int max;
	private boolean delay = false;
	private DjvuConverter main;
	
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public PageRangeDialog(Shell parent, DjvuConverter main, int from, int to) {
		super(parent);
		this.main = main;
		this.from = from;
		this.to = to;
		this.max = to;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.BORDER | SWT.APPLICATION_MODAL);
		shell.setSize(327, 80);
		shell.setText("Page range");

        org.eclipse.swt.graphics.Rectangle shellBounds = main.shell.getBounds();
        Point dialogSize = shell.getSize();

        shell.setLocation(
          shellBounds.x + (shellBounds.width - dialogSize.x) / 2,
          shellBounds.y + (shellBounds.height - dialogSize.y) / 2);		
		
		Label lblConvertBookPages = new Label(shell, SWT.NONE);
		lblConvertBookPages.setAlignment(SWT.CENTER);
		lblConvertBookPages.setBounds(10, 13, 124, 13);
		lblConvertBookPages.setText("Convert book pages from");
		
		inputFrom = new Text(shell, SWT.BORDER);
		inputFrom.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				try {
					delay = false;
					int x = Integer.parseInt((inputFrom.getText()));
					if ( x < 1 ) {
						x = 1;
						delay = true;
					}
					if ( x > max ) {
						x = max;
						delay = true;
					}
					from = x;
				} catch (NumberFormatException e1) {
					delay = true;
				}
				inputFrom.setText(""+from);
			}
		});
		inputFrom.setBounds(148, 10, 50, 19);
		inputFrom.setText(""+from);
		
		Label lblTo = new Label(shell, SWT.NONE);
		lblTo.setAlignment(SWT.CENTER);
		lblTo.setBounds(207, 13, 23, 13);
		lblTo.setText("to");
		
		inputTo = new Text(shell, SWT.BORDER);
		inputTo.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				try {
					delay = false;
					int x = Integer.parseInt((inputTo.getText()));
					if ( x < 1 ) {
						x = 1;
						delay = true;
					}
					if ( x > max ) {
						x = max;
						delay = true;
					}
					to = x;
				} catch (NumberFormatException e1) {
					delay = true;
				}
				inputTo.setText(""+to);
			}
		});
		inputTo.setBounds(238, 10, 50, 19);
		inputTo.setText(""+to);
		
		
		Button btnOk = new Button(shell, SWT.NONE);
		btnOk.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				if ( delay ) {
					delay = false;
					return;
				}
				shell.dispose();
			}
		});
		btnOk.setBounds(103, 44, 124, 20);
		btnOk.setText("OK");
	}
}
