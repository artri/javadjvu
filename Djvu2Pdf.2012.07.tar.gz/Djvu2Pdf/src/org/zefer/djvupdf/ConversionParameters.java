package org.zefer.djvupdf;

import java.util.HashSet;
import java.util.Properties;

public class ConversionParameters {

//	public boolean doublePageScan;
	public boolean split;

	public boolean autocrop;
	public boolean proportional = true;
	public boolean edgeFilter;
	public Margins marginsNormal = new Margins();
	public Margins marginsAutocrop = new Margins();

	public int hiedge;
	public int loedge;
	public int filter = 0;

	public double imageScale = 1.5;
	public double jpegQual = 0.2;
	
	public int imageType = 1; // 0 = JPEGBW, 1 = JPEG, 2 = PNG, 3 = indexed PNG
	
	public void save( Properties props, int nr ) {
		
		String pageNumber = String.format("%04d", nr);
		
		props.put("page." + pageNumber + ".split", ""+split );
		props.put("page." + pageNumber + ".autocrop", ""+autocrop );
		props.put("page." + pageNumber + ".proportional", ""+proportional );
		props.put("page." + pageNumber + ".edges", ""+edgeFilter );
		props.put("page." + pageNumber + ".hiedge", ""+hiedge);
		props.put("page." + pageNumber + ".loedge", ""+loedge);
		props.put("page." + pageNumber + ".filter", ""+filter);
		props.put("page." + pageNumber + ".image.scale", ""+imageScale);
		props.put("page." + pageNumber + ".jpeg.qual", ""+jpegQual);
		props.put("page." + pageNumber + ".image.type", ""+imageType);

		props.put("page." + pageNumber + ".margins.norm.left", "" + marginsNormal.left );
		props.put("page." + pageNumber + ".margins.norm.top", "" + marginsNormal.top );
		props.put("page." + pageNumber + ".margins.norm.right", "" + marginsNormal.right );
		props.put("page." + pageNumber + ".margins.norm.bottom", "" + marginsNormal.bottom );
		props.put("page." + pageNumber + ".margins.autocrop.left", "" + marginsAutocrop.left );
		props.put("page." + pageNumber + ".margins.autocrop.top", "" + marginsAutocrop.top );
		props.put("page." + pageNumber + ".margins.autocrop.right", "" + marginsAutocrop.right );
		props.put("page." + pageNumber + ".margins.autocrop.bottom", "" + marginsAutocrop.bottom );
	}
	
	public void load( Properties props, int nr ) {

		String pageNumber = String.format("%04d", nr);
		
		split = "true".equalsIgnoreCase(props.getProperty("page." + pageNumber + ".split" ));
		autocrop = "true".equalsIgnoreCase(props.getProperty("page." + pageNumber + ".autocrop" ));
		proportional = "true".equalsIgnoreCase(props.getProperty("page." + pageNumber + ".proportional" ));
		edgeFilter = "true".equalsIgnoreCase(props.getProperty("page." + pageNumber + ".edges" ));
		
		hiedge= Integer.parseInt(props.getProperty("page." + pageNumber + ".hiedge"));
		loedge = Integer.parseInt(props.getProperty("page." + pageNumber + ".loedge"));
		filter = Integer.parseInt(props.getProperty("page." + pageNumber + ".filter"));
		imageScale = Double.parseDouble(props.getProperty("page." + pageNumber + ".image.scale"));
		jpegQual = Double.parseDouble(props.getProperty("page." + pageNumber + ".jpeg.qual"));
		imageType = Integer.parseInt(props.getProperty("page." + pageNumber + ".image.type"));

		marginsNormal.left = Integer.parseInt(props.getProperty("page." + pageNumber + ".margins.norm.left" ));
		marginsNormal.top = Integer.parseInt(props.getProperty("page." + pageNumber + ".margins.norm.top" ));
		marginsNormal.right = Integer.parseInt(props.getProperty("page." + pageNumber + ".margins.norm.right" ));
		marginsNormal.bottom = Integer.parseInt(props.getProperty("page." + pageNumber + ".margins.norm.bottom" ));
		
		marginsAutocrop.left = Integer.parseInt(props.getProperty("page." + pageNumber + ".margins.autocrop.left" ));
		marginsAutocrop.top = Integer.parseInt(props.getProperty("page." + pageNumber + ".margins.autocrop.top" ));
		marginsAutocrop.right = Integer.parseInt(props.getProperty("page." + pageNumber + ".margins.autocrop.right" ));
		marginsAutocrop.bottom = Integer.parseInt(props.getProperty("page." + pageNumber + ".margins.autocrop.bottom" ));
	}
	
	public ConversionParameters clone() {
		ConversionParameters copy = new ConversionParameters();

//		copy.doublePageScan = doublePageScan;
		copy.split = split;
		copy.autocrop = autocrop;
		copy.proportional = proportional;
		copy.edgeFilter = edgeFilter;
		
		copy.hiedge = hiedge;
		copy.loedge = loedge;
		
		copy.imageScale = imageScale;
		copy.jpegQual = jpegQual;
		copy.filter = filter;
		copy.imageType = imageType;
		
		copy.marginsNormal = marginsNormal.clone();
		copy.marginsAutocrop = marginsAutocrop.clone();
		
		return copy;
	}
	
	public String[] differs( ConversionParameters other ) {
		HashSet result = new HashSet();

		if ( 
//				other.doublePageScan != doublePageScan || 
				other.split != split ) {
			result.add("3");
		}
		
		if( other.autocrop != autocrop || other.proportional != proportional || other.edgeFilter != edgeFilter ||
				!other.marginsNormal.equals(marginsNormal) || !other.marginsAutocrop.equals(marginsAutocrop) ) {
			result.add("4");			
		}
		
		if( other.hiedge != hiedge || other.loedge != loedge || other.imageScale != imageScale || 
				other.jpegQual != jpegQual || other.filter != filter || other.imageType != imageType ) {
			result.add("5");			
		}
		
		int size = result.size();
		if ( size == 0 ) {
			return null;
		} 
		
		Object[] oo = result.toArray();
		String[] res = new String[size];
		for ( int i = 0; i < size; i++ ) {
			res[i] = (String)oo[i];
		}
		
		return res;
	}
	
	public int getLeftMargin() {
		if ( autocrop ) {
			return marginsAutocrop.left;
		} else {
			return marginsNormal.left;
		}
	}
	
	public int getRightMargin() {
		if ( autocrop ) {
			return marginsAutocrop.right;
		} else {
			return marginsNormal.right;
		}
	}
	
	public int getTopMargin() {
		if ( autocrop ) {
			return marginsAutocrop.top;
		} else {
			return marginsNormal.top;
		}
	}
	
	public int getBottomMargin() {
		if ( autocrop ) {
			return marginsAutocrop.bottom;
		} else {
			return marginsNormal.bottom;
		}
	}

	public void setLeftMargin( int value ) {
		if ( autocrop ) {
			marginsAutocrop.left = value;
		} else {
			marginsNormal.left = value;
		}
	}
	
	public void setRightMargin( int value ) {
		if ( autocrop ) {
			marginsAutocrop.right = value;
		} else {
			marginsNormal.right = value;
		}
	}
	
	public void setTopMargin( int value ) {
		if ( autocrop ) {
			marginsAutocrop.top = value;
		} else {
			marginsNormal.top = value;
		}
	}
	
	public void setBottomMargin( int value ) {
		if ( autocrop ) {
			marginsAutocrop.bottom = value;
		} else {
			marginsNormal.bottom = value;
		}
	}
}
