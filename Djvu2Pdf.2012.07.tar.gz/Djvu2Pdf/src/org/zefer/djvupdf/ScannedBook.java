package org.zefer.djvupdf;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;

import org.eclipse.swt.widgets.Display;
import org.zefer.djvupdf.Book.BookPage;

public class ScannedBook extends Book {

	private File documentDirectory;
	private String[] pages;
	
	public ScannedBook( String activeDocumentDirectory, boolean doublePage, int targetWidth, int targetHeight ) throws IOException {
		documentDirectory = new File(activeDocumentDirectory);
        pages = documentDirectory.list( new FilenameFilter() {
        	public boolean accept(File dir, String name) {
        		name = name.toLowerCase();
        		if ( name.endsWith(".png") ||
       				name.endsWith(".jpg") ||
       				name.endsWith(".jpeg") ||
       				name.endsWith(".gif") ||
       				name.endsWith(".tif") ||
       				name.endsWith(".tiff") ||
       				name.endsWith(".wbmp") ||
       				name.endsWith(".bmp") ) {
        			return true;
        		}
        		return false;
        	}
        });
		
		this.doublePage = doublePage;
		this.targetHeight = targetHeight;
		this.targetWidth = targetWidth;
	}

	public static class NullPrintStream extends OutputStream {
		public void write(byte[] buf, int off, int len) {}
		public void write(int b) {}
		public void write(byte [] b) {}
	}

	public int getTotalPages() {
		return pages.length * (doublePage ? 2 : 1);
	}

	public BookPage getPage( int pageNumber, boolean split, double imageScale, Display display, boolean background ) throws IOException {
		
		BufferedImage ii;
		
		if ( doublePage ) {
			boolean left = pageNumber % 2 == 0;
			pageNumber /= 2;

			File filePath = new File(documentDirectory, pages[pageNumber]);
			BufferedImage bi = Util.readImage(filePath, display);
			int width = bi.getWidth();
			int height = bi.getHeight();
			
			ii = new BufferedImage(width/2, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D graphics2D = ii.createGraphics();
			
			if ( left ) {
				graphics2D.drawImage(bi, 0, 0, null);
			} else {
				graphics2D.drawImage(bi, -width/2, 0, null);
			}
			graphics2D.dispose();
			
		} else {
			File filePath = new File(documentDirectory, pages[pageNumber]);
			ii = Util.readImage(filePath, display);  
		}
		
		BookPage result = new BookPage();

		result.width = ii.getWidth();
		result.height = ii.getHeight();
		result.data = Util.getRGB(ii, 0, 0, result.width, result.height, result.data);
		
		return result;
	}
}
